"""
dashboard/app.py - Teen Mental Health Pipeline Dashboard
Production-grade Streamlit dashboard with all analytics features.
"""

import os
import sys
import json
import pickle
import sqlite3
from datetime import datetime
from typing import Optional

import pandas as pd
import numpy as np
import streamlit as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from matplotlib.patches import FancyBboxPatch
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ─── PATHS ──────────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLEAN_DATA   = os.path.join(BASE, "data", "processed", "clean_data.csv")
FEATURE_DATA = os.path.join(BASE, "data", "features", "feature_data.csv")
RISK_DATA    = os.path.join(BASE, "data", "outputs", "data_with_risk.csv")
PRED_DATA    = os.path.join(BASE, "data", "outputs", "prediction_results.csv")
MODEL_PATH   = os.path.join(BASE, "models", "risk_model.pkl")
METRICS_PATH = os.path.join(BASE, "reports", "model_metrics.json")
VALIDATION_REPORT = os.path.join(BASE, "data", "outputs", "data_validation_report.json")
ALERT_LOG    = os.path.join(BASE, "logs", "alerts.log")
VERSION_INDEX = os.path.join(BASE, "data", "versions", "version_index.json")
DB_PATH      = os.path.join(BASE, "data", "mental_health.db")

# ─── THEME ──────────────────────────────────────────────────────────────────
BG       = "#0D1117"
BG2      = "#161B22"
BORDER   = "#30363D"
TEXT     = "#E6EDF3"
TEXT_DIM = "#8B949E"
BLUE     = "#58A6FF"
GREEN    = "#3FB950"
RED      = "#F85149"
ORANGE   = "#FF8C42"
PURPLE   = "#BC8CFF"

TIER_COLORS = {
    "MINIMAL": "#3FB950",
    "LOW": "#58A6FF",
    "MODERATE": "#FF8C42",
    "HIGH": "#F85149",
    "CRITICAL": "#DA3633",
}

plt.rcParams.update({
    "figure.facecolor": BG2,
    "axes.facecolor": BG2,
    "axes.edgecolor": BORDER,
    "axes.labelcolor": TEXT,
    "xtick.color": TEXT_DIM,
    "ytick.color": TEXT_DIM,
    "text.color": TEXT,
    "grid.color": BORDER,
    "grid.alpha": 0.5,
})

# ─── PAGE CONFIG ────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Teen Mental Health Pipeline",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(f"""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');
  html, body, [class*="css"] {{ font-family: 'Inter', sans-serif !important; }}
  .stApp {{ background: {BG}; color: {TEXT}; }}
  .main .block-container {{ padding: 1.5rem 2rem; max-width: 1400px; }}
  section[data-testid="stSidebar"] {{ background: {BG2}; border-right: 1px solid {BORDER}; }}
  .metric-card {{
    background: {BG2}; border: 1px solid {BORDER}; border-radius: 10px;
    padding: 18px 20px; text-align: center; transition: border-color 0.2s;
  }}
  .metric-card:hover {{ border-color: {BLUE}; }}
  .metric-value {{ font-size: 2.2rem; font-weight: 700; line-height: 1; }}
  .metric-label {{ font-size: 0.75rem; color: {TEXT_DIM}; text-transform: uppercase;
                   letter-spacing: 0.06em; margin-top: 6px; }}
  .metric-delta {{ font-size: 0.78rem; margin-top: 4px; }}
  .section-header {{
    font-size: 1.1rem; font-weight: 600; color: {BLUE};
    border-bottom: 1px solid {BORDER}; padding-bottom: 8px; margin-bottom: 16px;
  }}
  .alert-card {{
    border-radius: 8px; padding: 10px 14px; margin-bottom: 8px;
    font-size: 0.85rem; display: flex; align-items: center; gap: 10px;
  }}
  .alert-CRITICAL {{ background: #2D1117; border-left: 3px solid {RED}; }}
  .alert-HIGH     {{ background: #2D1A0A; border-left: 3px solid {ORANGE}; }}
  .alert-MODERATE {{ background: #1A1F0A; border-left: 3px solid #C9D100; }}
  .alert-INFO     {{ background: #0A1929; border-left: 3px solid {BLUE}; }}
  .stButton>button {{
    background: {BG2}; color: {TEXT}; border: 1px solid {BORDER};
    border-radius: 6px; font-weight: 500; transition: all 0.2s;
  }}
  .stButton>button:hover {{ border-color: {BLUE}; color: {BLUE}; }}
  .version-pill {{
    display: inline-block; background: {BG2}; border: 1px solid {BORDER};
    border-radius: 20px; padding: 3px 12px; font-size: 0.75rem;
    font-family: 'JetBrains Mono', monospace; color: {TEXT_DIM};
  }}
  div[data-testid="stMetricValue"] {{ color: {TEXT} !important; }}
  .stSelectbox label, .stSlider label, .stNumberInput label {{ color: {TEXT_DIM} !important; }}
  h1 {{ color: {TEXT} !important; font-size: 1.8rem !important; font-weight: 700 !important; }}
  h2 {{ color: {BLUE} !important; font-size: 1.2rem !important; }}
  h3 {{ color: {TEXT} !important; font-size: 1rem !important; }}
</style>
""", unsafe_allow_html=True)


# ─── DATA LOADERS ───────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def load_data():
    dfs = {}
    for key, path in [
        ("clean", CLEAN_DATA), ("feature", FEATURE_DATA),
        ("risk", RISK_DATA), ("pred", PRED_DATA),
    ]:
        try:
            dfs[key] = pd.read_csv(path)
        except Exception:
            dfs[key] = pd.DataFrame()
    return dfs


@st.cache_data(ttl=300)
def load_metrics():
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH) as f:
            return json.load(f)
    return {}


@st.cache_data(ttl=300)
def load_validation_report():
    if os.path.exists(VALIDATION_REPORT):
        with open(VALIDATION_REPORT) as f:
            return json.load(f)
    return {}


@st.cache_data(ttl=300)
def load_model():
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)
    return None


def load_alerts(n=20):
    alerts = []
    if os.path.exists(ALERT_LOG):
        with open(ALERT_LOG) as f:
            for line in f:
                try:
                    alerts.append(json.loads(line.strip()))
                except Exception:
                    continue
    return alerts[-n:]


def load_version_index():
    if os.path.exists(VERSION_INDEX):
        with open(VERSION_INDEX) as f:
            return json.load(f)
    return {"versions": [], "latest": {}}


# ─── CHART HELPERS ──────────────────────────────────────────────────────────
def dark_fig(w=10, h=5):
    fig, ax = plt.subplots(figsize=(w, h), facecolor=BG2)
    ax.set_facecolor(BG2)
    ax.spines[:].set_color(BORDER)
    return fig, ax


def render_metric(label, value, color=TEXT, delta=None):
    delta_html = f'<div class="metric-delta" style="color:{GREEN if delta and delta > 0 else RED}">{("+" if delta and delta > 0 else "")}{delta}</div>' if delta else ""
    st.markdown(f"""
    <div class="metric-card">
      <div class="metric-value" style="color:{color}">{value}</div>
      <div class="metric-label">{label}</div>
      {delta_html}
    </div>""", unsafe_allow_html=True)


# ─── SIDEBAR ────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"### 🧠 Teen MH Pipeline")
    st.markdown(f'<span class="version-pill">v2.0.0 — Enhanced</span>', unsafe_allow_html=True)
    st.markdown("---")

    page = st.radio("Navigation", [
        "📊 Overview",
        "🔍 Data Quality",
        "📈 EDA & Correlations",
        "⚠️ Risk Analysis",
        "🤖 Model Performance",
        "🔮 Prediction",
        "🔔 Alert Center",
        "📁 Data Versioning",
    ], label_visibility="collapsed")

    st.markdown("---")
    if st.button("🔄 Refresh Data"):
        st.cache_data.clear()
        st.rerun()

    st.markdown("---")
    st.markdown(f'<span style="color:{TEXT_DIM};font-size:0.75rem">Last updated:<br>{datetime.now().strftime("%Y-%m-%d %H:%M")}</span>', unsafe_allow_html=True)

# ─── LOAD DATA ──────────────────────────────────────────────────────────────
data = load_data()
clean_df = data["clean"]
feature_df = data["feature"]
risk_df = data["risk"]
pred_df = data["pred"]
metrics = load_metrics()
val_report = load_validation_report()
bundle = load_model()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: OVERVIEW
# ════════════════════════════════════════════════════════════════════════════
if page == "📊 Overview":
    st.markdown("# 🧠 Teen Mental Health Pipeline")
    st.markdown(f'<p style="color:{TEXT_DIM}">Social Media Impact Analysis · Automated Data Engineering · ML Risk Prediction</p>', unsafe_allow_html=True)
    st.markdown("---")

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1: render_metric("Total Records", f"{len(clean_df):,}", BLUE)
    with c2:
        if not risk_df.empty and "risk_tier" in risk_df.columns:
            high_ct = int((risk_df["risk_tier"].isin(["HIGH", "CRITICAL"])).sum())
            render_metric("High Risk Cases", f"{high_ct:,}", RED)
        else:
            render_metric("High Risk Cases", "—")
    with c3:
        qs = val_report.get("overall_quality_score", "—")
        render_metric("Data Quality Score", f"{qs}", GREEN)
    with c4:
        if bundle:
            best_f1 = max((v.get("f1", 0) for v in metrics.values()), default=0)
            render_metric("Best Model F1", f"{best_f1:.4f}", PURPLE)
        else:
            render_metric("Best Model F1", "—")
    with c5:
        render_metric("Features Engineered", "14", ORANGE)

    st.markdown("---")

    col_l, col_r = st.columns([3, 2])

    with col_l:
        st.markdown('<div class="section-header">Risk Tier Distribution</div>', unsafe_allow_html=True)
        if not risk_df.empty and "risk_tier" in risk_df.columns:
            tiers = risk_df["risk_tier"].value_counts()
            fig, ax = dark_fig(8, 4)
            colors = [TIER_COLORS.get(t, TEXT_DIM) for t in tiers.index]
            bars = ax.barh(tiers.index, tiers.values, color=colors, edgecolor=BG, linewidth=2)
            for bar, val in zip(bars, tiers.values):
                ax.text(bar.get_width() + 3, bar.get_y() + bar.get_height() / 2,
                        f"{val} ({val/len(risk_df)*100:.1f}%)", va="center", color=TEXT, fontsize=10)
            ax.set_xlabel("Count", color=TEXT_DIM)
            ax.grid(axis="x", alpha=0.3)
            fig.tight_layout()
            st.pyplot(fig)
        else:
            st.info("Run the pipeline to generate risk data.")

    with col_r:
        st.markdown('<div class="section-header">Pipeline Status</div>', unsafe_allow_html=True)
        steps = [
            ("Data Ingestion", not clean_df.empty),
            ("Data Validation", bool(val_report)),
            ("Data Cleaning", not clean_df.empty),
            ("Feature Engineering", not feature_df.empty),
            ("Risk Scoring", not risk_df.empty),
            ("Model Training", bundle is not None),
            ("Prediction", not pred_df.empty),
        ]
        for step, ok in steps:
            icon = "✅" if ok else "⏳"
            color = GREEN if ok else TEXT_DIM
            st.markdown(f'<div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid {BORDER}"><span>{icon}</span><span style="color:{color};font-size:0.9rem">{step}</span></div>', unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: DATA QUALITY
# ════════════════════════════════════════════════════════════════════════════
elif page == "🔍 Data Quality":
    st.markdown("# 🔍 Data Quality Report")
    st.markdown("---")

    if val_report:
        qs = val_report.get("overall_quality_score", 0)
        qs_color = GREEN if qs >= 80 else ORANGE if qs >= 60 else RED

        c1, c2, c3, c4 = st.columns(4)
        with c1: render_metric("Overall Score", f"{qs}/100", qs_color)
        with c2: render_metric("Total Rows", f"{val_report.get('total_rows', 0):,}")
        with c3: render_metric("Missing Cells", f"{val_report['missing_values']['total_missing_cells']:,}", RED if val_report['missing_values']['total_missing_cells'] > 0 else GREEN)
        with c4: render_metric("Duplicate Rows", f"{val_report['duplicates']['count']:,}", RED if val_report['duplicates']['count'] > 0 else GREEN)

        st.markdown("---")
        col_l, col_r = st.columns(2)

        with col_l:
            st.markdown('<div class="section-header">Missing Values by Column</div>', unsafe_allow_html=True)
            mv = val_report["missing_values"]["per_column"]
            if mv:
                mv_df = pd.DataFrame(mv).T
                fig, ax = dark_fig(7, max(3, len(mv) * 0.5 + 1))
                ax.barh(mv_df.index, mv_df["pct"], color=RED, alpha=0.8)
                ax.set_xlabel("Missing %")
                ax.grid(axis="x", alpha=0.3)
                fig.tight_layout()
                st.pyplot(fig)
            else:
                st.success("✅ No missing values detected!")

        with col_r:
            st.markdown('<div class="section-header">Range Violations</div>', unsafe_allow_html=True)
            rv = val_report.get("range_violations", {})
            if rv:
                for col, info in rv.items():
                    st.markdown(f"""
                    <div style="background:{BG2};border:1px solid {BORDER};border-radius:8px;padding:10px;margin-bottom:8px">
                      <strong style="color:{ORANGE}">{col}</strong><br>
                      <span style="color:{TEXT_DIM};font-size:0.82rem">Out of range: {info['out_of_range']} | Allowed: [{info['min_allowed']}, {info['max_allowed']}]</span>
                    </div>""", unsafe_allow_html=True)
            else:
                st.success("✅ No range violations detected!")

        st.markdown('<div class="section-header">Outlier Summary</div>', unsafe_allow_html=True)
        outliers = val_report.get("outliers", {})
        if outliers:
            out_df = pd.DataFrame(outliers).T.reset_index().rename(columns={"index": "column"})
            st.dataframe(out_df.style.background_gradient(subset=["count"], cmap="Reds"), use_container_width=True)
        else:
            st.success("✅ No significant outliers detected!")
    else:
        st.warning("Run the pipeline to generate validation report.")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: EDA & CORRELATIONS
# ════════════════════════════════════════════════════════════════════════════
elif page == "📈 EDA & Correlations":
    st.markdown("# 📈 Exploratory Data Analysis")
    st.markdown("---")

    if clean_df.empty:
        st.warning("No data available. Run the pipeline first.")
        st.stop()

    numeric_cols = clean_df.select_dtypes(include=[np.number]).columns.tolist()

    # Correlation heatmap
    st.markdown('<div class="section-header">Correlation Matrix</div>', unsafe_allow_html=True)
    corr = clean_df[numeric_cols].corr()
    fig, ax = plt.subplots(figsize=(12, 9), facecolor=BG2)
    ax.set_facecolor(BG2)
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
                center=0, ax=ax, linewidths=0.5, linecolor=BORDER,
                annot_kws={"size": 8, "color": TEXT}, cbar_kws={"shrink": 0.8})
    ax.set_title("Feature Correlation Matrix", color=TEXT, fontsize=13, pad=14)
    ax.tick_params(colors=TEXT_DIM, labelsize=8)
    fig.tight_layout()
    st.pyplot(fig)

    st.markdown("---")
    col_l, col_r = st.columns(2)

    with col_l:
        st.markdown('<div class="section-header">Distribution Explorer</div>', unsafe_allow_html=True)
        sel_col = st.selectbox("Select feature", numeric_cols)
        fig, ax = dark_fig(7, 4)
        d = clean_df[sel_col].dropna()
        ax.hist(d, bins=35, color=BLUE, alpha=0.8, edgecolor=BG)
        ax.axvline(d.mean(), color=RED, linestyle="--", linewidth=2, label=f"Mean: {d.mean():.2f}")
        ax.axvline(d.median(), color=GREEN, linestyle=":", linewidth=2, label=f"Median: {d.median():.2f}")
        ax.set_title(f"Distribution of {sel_col}", color=TEXT)
        ax.legend(framealpha=0.3)
        fig.tight_layout()
        st.pyplot(fig)

    with col_r:
        st.markdown('<div class="section-header">Sleep vs Anxiety</div>', unsafe_allow_html=True)
        if "sleep_hours" in clean_df and "anxiety_level" in clean_df:
            fig, ax = dark_fig(7, 4)
            sc = ax.scatter(clean_df["sleep_hours"], clean_df["anxiety_level"],
                            alpha=0.4, c=clean_df.get("stress_level", pd.Series([5]*len(clean_df))),
                            cmap="RdYlGn_r", s=25, edgecolors="none")
            plt.colorbar(sc, ax=ax, label="Stress Level")
            ax.set_xlabel("Sleep Hours")
            ax.set_ylabel("Anxiety Level")
            ax.set_title("Sleep vs Anxiety (color = Stress)", color=TEXT)

            # Trend line
            z = np.polyfit(clean_df["sleep_hours"].dropna(), clean_df["anxiety_level"].dropna(), 1)
            p = np.poly1d(z)
            xs = np.linspace(clean_df["sleep_hours"].min(), clean_df["sleep_hours"].max(), 100)
            ax.plot(xs, p(xs), "--", color=ORANGE, linewidth=2, alpha=0.8)
            fig.tight_layout()
            st.pyplot(fig)

    st.markdown("---")
    st.markdown('<div class="section-header">Social Media vs Stress</div>', unsafe_allow_html=True)
    if "daily_social_media_hours" in clean_df and "stress_level" in clean_df:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5), facecolor=BG2)
        for ax in [ax1, ax2]:
            ax.set_facecolor(BG2); ax.spines[:].set_color(BORDER)

        ax1.scatter(clean_df["daily_social_media_hours"], clean_df["stress_level"],
                    alpha=0.35, color=PURPLE, s=20, edgecolors="none")
        z = np.polyfit(clean_df["daily_social_media_hours"], clean_df["stress_level"], 1)
        p = np.poly1d(z)
        xs = np.linspace(0, clean_df["daily_social_media_hours"].max(), 100)
        ax1.plot(xs, p(xs), "--", color=RED, linewidth=2)
        ax1.set_xlabel("Social Media Hours/Day"); ax1.set_ylabel("Stress Level")
        ax1.set_title("Social Media vs Stress", color=TEXT)
        ax1.tick_params(colors=TEXT_DIM)

        sm_bins = pd.cut(clean_df["daily_social_media_hours"], bins=[0, 2, 4, 6, 8, 15], labels=["0-2", "2-4", "4-6", "6-8", "8+"])
        stress_by_usage = clean_df.groupby(sm_bins, observed=True)["stress_level"].mean()
        bars = ax2.bar(stress_by_usage.index, stress_by_usage.values, color=[BLUE, GREEN, ORANGE, RED, "#DA3633"], alpha=0.85, edgecolor=BG)
        for bar, val in zip(bars, stress_by_usage.values):
            ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.05,
                     f"{val:.1f}", ha="center", va="bottom", color=TEXT, fontsize=9)
        ax2.set_xlabel("Social Media Usage (hrs/day)"); ax2.set_ylabel("Avg Stress Level")
        ax2.set_title("Avg Stress by Usage Tier", color=TEXT)
        ax2.tick_params(colors=TEXT_DIM)

        fig.tight_layout()
        st.pyplot(fig)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: RISK ANALYSIS
# ════════════════════════════════════════════════════════════════════════════
elif page == "⚠️ Risk Analysis":
    st.markdown("# ⚠️ Risk Analysis")
    st.markdown("---")

    if risk_df.empty or "risk_tier" not in risk_df.columns:
        st.warning("No risk data. Run the pipeline first.")
        st.stop()

    tier_filter = st.multiselect("Filter by Risk Tier", ["MINIMAL", "LOW", "MODERATE", "HIGH", "CRITICAL"],
                                  default=["MODERATE", "HIGH", "CRITICAL"])
    filtered = risk_df[risk_df["risk_tier"].isin(tier_filter)] if tier_filter else risk_df

    c1, c2, c3, c4 = st.columns(4)
    with c1: render_metric("Filtered Records", f"{len(filtered):,}", BLUE)
    with c2: render_metric("Avg Risk Score", f"{filtered['risk_score'].mean():.1f}" if "risk_score" in filtered.columns else "—", ORANGE)
    with c3: render_metric("Max Risk Score", f"{filtered['risk_score'].max():.1f}" if "risk_score" in filtered.columns else "—", RED)
    with c4: render_metric("% of Total", f"{len(filtered)/len(risk_df)*100:.1f}%", PURPLE)

    st.markdown("---")
    col_l, col_r = st.columns(2)

    with col_l:
        st.markdown('<div class="section-header">Risk Score Distribution</div>', unsafe_allow_html=True)
        if "risk_score" in filtered.columns:
            fig, ax = dark_fig(7, 4)
            ax.hist(filtered["risk_score"], bins=40, color=ORANGE, alpha=0.8, edgecolor=BG)
            ax.axvline(filtered["risk_score"].mean(), color=RED, linestyle="--", linewidth=2, label=f"Mean: {filtered['risk_score'].mean():.1f}")
            ax.set_xlabel("Risk Score (0–100)")
            ax.set_ylabel("Count")
            ax.set_title("Risk Score Distribution", color=TEXT)
            ax.legend(framealpha=0.3)
            ax.grid(alpha=0.3)
            fig.tight_layout()
            st.pyplot(fig)

    with col_r:
        st.markdown('<div class="section-header">Risk by Platform</div>', unsafe_allow_html=True)
        if "platform_usage" in filtered.columns and "risk_score" in filtered.columns:
            plat_risk = filtered.groupby("platform_usage")["risk_score"].mean().sort_values(ascending=False)
            fig, ax = dark_fig(7, 4)
            colors = plt.cm.RdYlGn_r(np.linspace(0.2, 0.8, len(plat_risk)))
            bars = ax.barh(plat_risk.index, plat_risk.values, color=colors, alpha=0.85, edgecolor=BG)
            for bar, val in zip(bars, plat_risk.values):
                ax.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height() / 2,
                        f"{val:.1f}", va="center", color=TEXT, fontsize=9)
            ax.set_xlabel("Avg Risk Score")
            ax.set_title("Avg Risk Score by Platform", color=TEXT)
            ax.grid(axis="x", alpha=0.3)
            fig.tight_layout()
            st.pyplot(fig)

    st.markdown('<div class="section-header">Behavioral Profile Breakdown</div>', unsafe_allow_html=True)
    if "behavioral_profile" in filtered.columns:
        prof_counts = filtered.groupby(["behavioral_profile", "risk_tier"]).size().unstack(fill_value=0)
        fig, ax = dark_fig(12, 4)
        prof_counts.plot(kind="bar", ax=ax, color=[TIER_COLORS.get(c, TEXT_DIM) for c in prof_counts.columns],
                         edgecolor=BG, linewidth=0.5)
        ax.set_xlabel("")
        ax.set_ylabel("Count")
        ax.set_title("Risk Tier by Behavioral Profile", color=TEXT)
        ax.legend(title="Risk Tier", framealpha=0.3, title_fontsize=9)
        ax.tick_params(axis="x", rotation=15)
        fig.tight_layout()
        st.pyplot(fig)

    st.markdown("---")
    st.markdown('<div class="section-header">🚨 High Risk Case Table</div>', unsafe_allow_html=True)
    high_risk = filtered[filtered["risk_tier"].isin(["HIGH", "CRITICAL"])].head(50)
    if not high_risk.empty:
        display_cols = [c for c in ["age", "gender", "daily_social_media_hours", "sleep_hours",
                                     "stress_level", "anxiety_level", "risk_score", "risk_tier"] if c in high_risk.columns]
        st.dataframe(high_risk[display_cols].reset_index(drop=True), use_container_width=True)
    else:
        st.info("No HIGH/CRITICAL cases in current filter.")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: MODEL PERFORMANCE
# ════════════════════════════════════════════════════════════════════════════
elif page == "🤖 Model Performance":
    st.markdown("# 🤖 Model Performance")
    st.markdown("---")

    if not metrics:
        st.warning("No model metrics available. Run the pipeline first.")
        st.stop()

    model_names = list(metrics.keys())
    metric_keys = ["accuracy", "precision", "recall", "f1", "roc_auc"]
    metric_labels = ["Accuracy", "Precision", "Recall", "F1 Score", "ROC AUC"]

    # KPI row for best model
    best_model_name = max(metrics, key=lambda m: metrics[m].get("f1", 0))
    best = metrics[best_model_name]
    st.markdown(f'<div class="section-header">🏆 Best Model: {best_model_name}</div>', unsafe_allow_html=True)
    cols = st.columns(5)
    pairs = zip(metric_labels, metric_keys)
    colors_list = [GREEN, BLUE, ORANGE, PURPLE, RED]
    for col, (label, key), color in zip(cols, pairs, colors_list):
        with col:
            render_metric(label, f"{best.get(key, 0):.4f}", color)

    st.markdown("---")

    # Comparison bar chart
    st.markdown('<div class="section-header">Model Comparison</div>', unsafe_allow_html=True)
    fig, axes = plt.subplots(1, len(metric_keys), figsize=(16, 5), facecolor=BG)
    model_colors = [BLUE, GREEN, ORANGE]
    for ax, mkey, mlabel in zip(axes, metric_keys, metric_labels):
        ax.set_facecolor(BG2)
        ax.spines[:].set_color(BORDER)
        vals = [metrics[m].get(mkey, 0) or 0 for m in model_names]
        bars = ax.bar(model_names, vals, color=model_colors[:len(model_names)], alpha=0.85, edgecolor=BG, linewidth=0)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.008,
                    f"{val:.3f}", ha="center", va="bottom", fontsize=8, color=TEXT)
        ax.set_ylim(0, 1.12)
        ax.set_title(mlabel, color=TEXT, fontsize=11)
        ax.set_xticks(range(len(model_names)))
        ax.set_xticklabels(model_names, rotation=15, ha="right", fontsize=8, color=TEXT_DIM)
        ax.tick_params(colors=TEXT_DIM)
        ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    st.pyplot(fig)

    st.markdown("---")
    col_l, col_r = st.columns(2)
    with col_l:
        st.markdown('<div class="section-header">Confusion Matrix</div>', unsafe_allow_html=True)
        sel_model = st.selectbox("Select model", model_names, key="cm_sel")
        cm = np.array(metrics[sel_model]["confusion_matrix"])
        fig, ax = plt.subplots(figsize=(5, 4), facecolor=BG2)
        ax.set_facecolor(BG2)
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax, linewidths=0.5,
                    linecolor=BORDER, annot_kws={"size": 14, "color": TEXT},
                    xticklabels=["Low Risk", "High Risk"], yticklabels=["Low Risk", "High Risk"])
        ax.set_title(f"Confusion Matrix — {sel_model}", color=TEXT)
        ax.tick_params(colors=TEXT_DIM)
        fig.tight_layout()
        st.pyplot(fig)

    with col_r:
        st.markdown('<div class="section-header">CV Performance</div>', unsafe_allow_html=True)
        cv_data = {m: {"CV F1 Mean": metrics[m].get("cv_f1_mean", 0),
                       "CV F1 Std": metrics[m].get("cv_f1_std", 0)} for m in model_names}
        cv_df = pd.DataFrame(cv_data).T
        fig, ax = dark_fig(6, 4)
        x = np.arange(len(cv_df))
        bars = ax.bar(x, cv_df["CV F1 Mean"], yerr=cv_df["CV F1 Std"], color=model_colors[:len(x)],
                      capsize=6, alpha=0.85, edgecolor=BG, linewidth=0, error_kw={"ecolor": TEXT_DIM, "linewidth": 1.5})
        ax.set_xticks(x)
        ax.set_xticklabels(cv_df.index, rotation=10, ha="right", fontsize=9)
        ax.set_ylabel("CV F1 Score")
        ax.set_title("Cross-Validation F1 (5-Fold ± std)", color=TEXT)
        ax.set_ylim(0, 1.0)
        ax.grid(axis="y", alpha=0.3)
        for bar, (_, row) in zip(bars, cv_df.iterrows()):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + row["CV F1 Std"] + 0.02,
                    f"{row['CV F1 Mean']:.3f}", ha="center", color=TEXT, fontsize=9)
        fig.tight_layout()
        st.pyplot(fig)

    # Feature importance
    if bundle and "feature_names" in bundle:
        st.markdown('<div class="section-header">Feature Importances (Best Model)</div>', unsafe_allow_html=True)
        clf = bundle["model"]
        estimator = clf.named_steps.get("clf", clf)
        if hasattr(estimator, "feature_importances_"):
            fi = pd.Series(estimator.feature_importances_, index=bundle["feature_names"]).sort_values(ascending=True).tail(12)
            fig, ax = dark_fig(10, 5)
            ax.barh(fi.index, fi.values, color=PURPLE, alpha=0.85, edgecolor=BG)
            ax.set_xlabel("Importance")
            ax.set_title(f"Top Feature Importances — {bundle['model_name']}", color=TEXT)
            ax.grid(axis="x", alpha=0.3)
            fig.tight_layout()
            st.pyplot(fig)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: PREDICTION
# ════════════════════════════════════════════════════════════════════════════
elif page == "🔮 Prediction":
    st.markdown("# 🔮 Risk Prediction")
    st.markdown("---")

    if not bundle:
        st.warning("No trained model found. Run the pipeline first.")
        st.stop()

    st.markdown(f'<div class="section-header">Input Individual Profile</div>', unsafe_allow_html=True)
    st.markdown(f'<p style="color:{TEXT_DIM};font-size:0.85rem">Model: {bundle["model_name"]} · Trained: {bundle.get("trained_at", "Unknown")[:10]}</p>', unsafe_allow_html=True)

    with st.form("prediction_form"):
        c1, c2, c3 = st.columns(3)
        with c1:
            age = st.number_input("Age", 10, 25, 16)
            daily_sm = st.slider("Daily Social Media (hrs)", 0.0, 12.0, 4.0, 0.5)
            sleep_h = st.slider("Sleep Hours", 3.0, 12.0, 7.0, 0.5)
            screen_before = st.slider("Screen Before Sleep (hrs)", 0.0, 6.0, 1.5, 0.5)
        with c2:
            academic = st.slider("Academic Performance (GPA)", 0.0, 4.0, 3.0, 0.1)
            physical = st.slider("Physical Activity (hrs/day)", 0.0, 5.0, 1.0, 0.25)
            stress = st.slider("Stress Level (1–10)", 1, 10, 5)
        with c3:
            anxiety = st.slider("Anxiety Level (1–10)", 1, 10, 4)
            addiction = st.slider("Addiction Level (1–10)", 1, 10, 4)
            social_int = st.selectbox("Social Interaction", ["low", "medium", "high"], index=1)
            gender_sel = st.selectbox("Gender", ["male", "female"], index=0)

        submitted = st.form_submit_button("🔮 Predict Risk", use_container_width=True)

    if submitted:
        si_map = {"low": 0, "medium": 1, "high": 2}
        eps = 1e-6
        row = {
            "daily_social_media_hours": daily_sm,
            "sleep_hours": sleep_h,
            "screen_time_before_sleep": screen_before,
            "physical_activity": physical,
            "stress_level": stress,
            "anxiety_level": anxiety,
            "addiction_level": addiction,
            "academic_performance": academic,
            "social_interaction_encoded": si_map[social_int],
            "gender_encoded": 1 if gender_sel == "female" else 0,
            "screen_sleep_ratio": daily_sm / (sleep_h + eps),
            "stress_activity_ratio": stress / (physical + eps),
            "social_sleep_gap": daily_sm - sleep_h,
            "mental_risk_index": (
                0.30 * min(daily_sm / 10, 1)
                + 0.20 * max(0, 1 - (sleep_h - 4) / 5)
                + 0.20 * (stress - 1) / 9
                + 0.15 * (anxiety - 1) / 9
                + 0.10 * (addiction - 1) / 9
                + 0.05 * max(0, 1 - physical / 5)
            ),
        }

        X = pd.DataFrame([row])
        X = X[[f for f in bundle["feature_names"] if f in X.columns]]
        for missing_feat in [f for f in bundle["feature_names"] if f not in X.columns]:
            X[missing_feat] = 0
        X = X[bundle["feature_names"]]

        model = bundle["model"]
        pred = model.predict(X)[0]
        prob = model.predict_proba(X)[0][1] if hasattr(model, "predict_proba") else 0.5

        st.markdown("---")
        col_a, col_b, col_c = st.columns(3)
        risk_label = "HIGH RISK" if pred == 1 else "LOW RISK"
        risk_color = RED if pred == 1 else GREEN

        with col_a:
            render_metric("Prediction", risk_label, risk_color)
        with col_b:
            render_metric("Risk Probability", f"{prob:.1%}", ORANGE)
        with col_c:
            mri = row["mental_risk_index"]
            render_metric("Risk Index", f"{mri:.3f}", PURPLE)

        # Risk gauge
        fig, ax = plt.subplots(figsize=(8, 3), facecolor=BG2)
        ax.set_facecolor(BG2)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)

        zones = [(0, 0.2, GREEN), (0.2, 0.5, BLUE), (0.5, 0.75, ORANGE), (0.75, 1.0, RED)]
        for lo, hi, col in zones:
            ax.barh(0.5, hi - lo, left=lo, height=0.3, color=col, alpha=0.7, edgecolor=BG, linewidth=0)

        ax.axvline(prob, color="white", linewidth=3, ymin=0.15, ymax=0.95, zorder=5)
        ax.text(prob, 0.9, f"{prob:.0%}", ha="center", color="white", fontweight="bold", fontsize=13)
        ax.set_xticks([0, 0.2, 0.5, 0.75, 1.0])
        ax.set_xticklabels(["0%", "20%", "50%", "75%", "100%"], color=TEXT_DIM)
        ax.set_yticks([])
        ax.set_title("Risk Probability Gauge", color=TEXT, fontsize=12)
        ax.spines[:].set_color(BORDER)
        for label, x in zip(["Minimal", "Low", "Moderate", "High"], [0.1, 0.35, 0.625, 0.875]):
            ax.text(x, 0.12, label, ha="center", color=TEXT_DIM, fontsize=8)
        fig.tight_layout()
        st.pyplot(fig)

        if pred == 1:
            st.error("⚠️ **High Risk Detected.** This individual shows behavioral patterns associated with elevated mental health risk. Consider intervention and support resources.")
        else:
            st.success("✅ **Low Risk.** This individual's behavioral profile is within normal ranges.")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: ALERT CENTER
# ════════════════════════════════════════════════════════════════════════════
elif page == "🔔 Alert Center":
    st.markdown("# 🔔 Alert Center")
    st.markdown("---")

    alerts = load_alerts(50)
    if not alerts:
        st.info("No alerts recorded yet. Run the pipeline to generate alerts.")
    else:
        severity_filter = st.multiselect("Filter by Severity",
                                          ["CRITICAL", "HIGH", "MODERATE", "INFO"],
                                          default=["CRITICAL", "HIGH", "MODERATE"])
        filtered_alerts = [a for a in reversed(alerts) if a.get("severity") in severity_filter]

        c1, c2, c3, c4 = st.columns(4)
        counts = {s: sum(1 for a in alerts if a.get("severity") == s) for s in ["CRITICAL", "HIGH", "MODERATE", "INFO"]}
        with c1: render_metric("CRITICAL", counts.get("CRITICAL", 0), RED)
        with c2: render_metric("HIGH", counts.get("HIGH", 0), ORANGE)
        with c3: render_metric("MODERATE", counts.get("MODERATE", 0), "#C9D100")
        with c4: render_metric("INFO", counts.get("INFO", 0), BLUE)

        st.markdown("---")
        icons = {"CRITICAL": "🔴", "HIGH": "🟠", "MODERATE": "🟡", "INFO": "🔵"}
        for alert in filtered_alerts[:20]:
            sev = alert.get("severity", "INFO")
            icon = icons.get(sev, "⚪")
            ts = alert.get("timestamp", "")[:19].replace("T", " ")
            meta_html = ""
            if alert.get("metadata"):
                meta_html = " · ".join(f'<code style="font-size:0.78rem;color:{TEXT_DIM}">{k}={v}</code>'
                                        for k, v in alert["metadata"].items())
            st.markdown(f"""
            <div class="alert-card alert-{sev}">
              <span style="font-size:1.1rem">{icon}</span>
              <div style="flex:1">
                <strong style="font-size:0.88rem">{alert.get('title','')}</strong><br>
                <span style="color:{TEXT_DIM};font-size:0.82rem">{alert.get('message','')}</span><br>
                <span style="color:{TEXT_DIM};font-size:0.75rem">{ts} · Run: {alert.get('run_id','—')} &nbsp; {meta_html}</span>
              </div>
            </div>""", unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════════════════════
# PAGE: DATA VERSIONING
# ════════════════════════════════════════════════════════════════════════════
elif page == "📁 Data Versioning":
    st.markdown("# 📁 Data Versioning")
    st.markdown("---")

    idx = load_version_index()
    versions = idx.get("versions", [])
    latest = idx.get("latest", {})

    if not versions:
        st.info("No versions yet. Run the pipeline to create data snapshots.")
    else:
        # Summary
        stages = list(set(v["stage"] for v in versions))
        c1, c2, c3 = st.columns(3)
        with c1: render_metric("Total Snapshots", len(versions), BLUE)
        with c2: render_metric("Pipeline Stages", len(stages), GREEN)
        with c3:
            latest_ts = max(v["timestamp"] for v in versions)[:16].replace("T", " ")
            render_metric("Latest Snapshot", latest_ts, PURPLE)

        st.markdown("---")
        st.markdown('<div class="section-header">Version History</div>', unsafe_allow_html=True)

        for stage in sorted(stages):
            stage_versions = [v for v in versions if v["stage"] == stage]
            is_latest = latest.get(stage, {})

            with st.expander(f"📦 **{stage.upper()}** — {len(stage_versions)} snapshot(s)", expanded=stage == "cleaned"):
                for v in reversed(stage_versions[-5:]):
                    is_lat = v["version_id"] == is_latest.get("version_id", "")
                    badge = f'<span style="background:#0D4429;color:#3FB950;border-radius:4px;padding:1px 8px;font-size:0.72rem;margin-left:8px">LATEST</span>' if is_lat else ""

                    st.markdown(f"""
                    <div style="background:{BG};border:1px solid {BORDER};border-radius:8px;padding:12px;margin-bottom:8px">
                      <div style="display:flex;align-items:center;gap:8px">
                        <code style="color:{BLUE};font-size:0.82rem">{v['version_id']}</code>{badge}
                      </div>
                      <div style="display:flex;gap:20px;margin-top:8px;font-size:0.8rem;color:{TEXT_DIM}">
                        <span>🕐 {v['timestamp'][:19].replace('T',' ')}</span>
                        <span>📊 {v['rows']:,} rows × {v['columns']} cols</span>
                        <span>🔑 <code style="font-size:0.75rem">{v['checksum_sha256'][:16]}...</code></span>
                      </div>
                      <div style="margin-top:4px;font-size:0.8rem;color:{TEXT_DIM}">{v.get('description','')}</div>
                    </div>""", unsafe_allow_html=True)

        st.markdown("---")
        st.markdown('<div class="section-header">Compare Two Versions</div>', unsafe_allow_html=True)
        version_ids = [v["version_id"] for v in versions]
        col_l, col_r = st.columns(2)
        with col_l:
            va = st.selectbox("Version A", version_ids, index=0)
        with col_r:
            vb = st.selectbox("Version B", version_ids, index=min(1, len(version_ids) - 1))

        if st.button("Compare", key="compare_btn") and va != vb:
            va_meta = next(v for v in versions if v["version_id"] == va)
            vb_meta = next(v for v in versions if v["version_id"] == vb)
            row_diff = vb_meta["rows"] - va_meta["rows"]
            col_diff = vb_meta["columns"] - va_meta["columns"]
            same_cs = va_meta["checksum_sha256"] == vb_meta["checksum_sha256"]

            c1, c2, c3, c4 = st.columns(4)
            with c1: render_metric("Row Δ", f"{row_diff:+d}", GREEN if row_diff >= 0 else RED)
            with c2: render_metric("Column Δ", f"{col_diff:+d}", GREEN if col_diff >= 0 else ORANGE)
            with c3: render_metric("Same Content", "YES" if same_cs else "NO", GREEN if same_cs else RED)
            with c4: render_metric("Data Changed", "NO" if same_cs else "YES", GREEN if same_cs else ORANGE)
