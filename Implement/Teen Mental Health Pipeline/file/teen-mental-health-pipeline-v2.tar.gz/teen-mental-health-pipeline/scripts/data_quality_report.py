"""
data_quality_report.py - Data Quality Report Generator
Produces a comprehensive HTML + JSON quality report with visualizations.
"""

import os
import json
from datetime import datetime
from typing import Optional
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import base64
from io import BytesIO

from scripts.logger import get_logger

logger = get_logger("data_quality_report")

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)


def _fig_to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format="png", dpi=120, bbox_inches="tight", facecolor=fig.get_facecolor())
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode("utf-8")
    plt.close(fig)
    return encoded


def plot_missing_values(df: pd.DataFrame) -> str:
    missing = df.isnull().sum()
    missing = missing[missing > 0]
    if missing.empty:
        return ""

    fig, ax = plt.subplots(figsize=(10, 4), facecolor="#0D1117")
    bars = ax.barh(missing.index, missing.values / len(df) * 100,
                   color="#FF5722", alpha=0.85, edgecolor="#FF8A65")
    ax.set_xlabel("Missing %", color="#E6EDF3")
    ax.set_title("Missing Value Analysis", color="#E6EDF3", fontsize=13)
    ax.set_facecolor("#161B22")
    ax.tick_params(colors="#E6EDF3")
    ax.spines[:].set_color("#30363D")
    for bar, val in zip(bars, missing.values / len(df) * 100):
        ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height() / 2,
                f"{val:.1f}%", va="center", color="#E6EDF3", fontsize=9)
    fig.tight_layout()
    return _fig_to_base64(fig)


def plot_distributions(df: pd.DataFrame) -> str:
    numeric_cols = df.select_dtypes(include=[np.number]).columns[:8]
    n = len(numeric_cols)
    if n == 0:
        return ""

    cols_per_row = 4
    rows = (n + cols_per_row - 1) // cols_per_row
    fig, axes = plt.subplots(rows, cols_per_row, figsize=(16, rows * 3.5), facecolor="#0D1117")
    axes = axes.flatten()

    for i, col in enumerate(numeric_cols):
        ax = axes[i]
        ax.set_facecolor("#161B22")
        data = df[col].dropna()
        ax.hist(data, bins=30, color="#2196F3", alpha=0.75, edgecolor="#1565C0")
        ax.axvline(data.mean(), color="#FF5722", linestyle="--", linewidth=1.5, label=f"Mean={data.mean():.1f}")
        ax.axvline(data.median(), color="#4CAF50", linestyle=":", linewidth=1.5, label=f"Median={data.median():.1f}")
        ax.set_title(col, color="#E6EDF3", fontsize=10)
        ax.tick_params(colors="#8B949E", labelsize=8)
        ax.spines[:].set_color("#30363D")
        ax.legend(fontsize=7, framealpha=0.3, labelcolor="#E6EDF3")

    for j in range(i + 1, len(axes)):
        axes[j].set_visible(False)

    fig.suptitle("Feature Distributions", color="#E6EDF3", fontsize=14, y=1.01)
    fig.tight_layout()
    return _fig_to_base64(fig)


def plot_correlation(df: pd.DataFrame) -> str:
    numeric = df.select_dtypes(include=[np.number]).dropna()
    if numeric.empty:
        return ""

    corr = numeric.corr()
    fig, ax = plt.subplots(figsize=(12, 10), facecolor="#0D1117")
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
        center=0, ax=ax, linewidths=0.5, linecolor="#30363D",
        annot_kws={"size": 7}, cbar_kws={"shrink": 0.8}
    )
    ax.set_facecolor("#161B22")
    ax.set_title("Correlation Matrix", color="#E6EDF3", fontsize=13)
    ax.tick_params(colors="#E6EDF3", labelsize=8)
    fig.tight_layout()
    return _fig_to_base64(fig)


def plot_outliers(df: pd.DataFrame) -> str:
    numeric_cols = df.select_dtypes(include=[np.number]).columns[:8]
    if len(numeric_cols) == 0:
        return ""

    fig, ax = plt.subplots(figsize=(14, 5), facecolor="#0D1117")
    ax.set_facecolor("#161B22")

    data_for_box = [df[col].dropna().values for col in numeric_cols]
    bp = ax.boxplot(data_for_box, patch_artist=True, notch=False,
                    medianprops={"color": "#FF5722", "linewidth": 2},
                    flierprops={"marker": "o", "markerfacecolor": "#FF5722", "markersize": 3, "alpha": 0.5})

    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(numeric_cols)))
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.8)

    ax.set_xticks(range(1, len(numeric_cols) + 1))
    ax.set_xticklabels(numeric_cols, rotation=30, ha="right", color="#E6EDF3", fontsize=9)
    ax.tick_params(colors="#8B949E")
    ax.spines[:].set_color("#30363D")
    ax.set_title("Outlier Detection (Box Plot)", color="#E6EDF3", fontsize=13)
    fig.tight_layout()
    return _fig_to_base64(fig)


def compute_quality_metrics(df: pd.DataFrame) -> dict:
    total_cells = len(df) * len(df.columns)
    missing_cells = int(df.isnull().sum().sum())
    dup_rows = int(df.duplicated().sum())
    completeness = round((1 - missing_cells / total_cells) * 100, 2)
    uniqueness = round((1 - dup_rows / len(df)) * 100, 2)

    numeric = df.select_dtypes(include=[np.number])
    validity = 100.0
    if not numeric.empty:
        outlier_pct = sum(
            ((numeric[col] < numeric[col].quantile(0.01)) |
             (numeric[col] > numeric[col].quantile(0.99))).sum()
            for col in numeric.columns
        ) / (len(df) * len(numeric.columns)) * 100
        validity = round(max(0, 100 - outlier_pct * 5), 2)

    overall = round((completeness * 0.4 + uniqueness * 0.3 + validity * 0.3), 2)

    return {
        "completeness": completeness,
        "uniqueness": uniqueness,
        "validity": validity,
        "overall_score": overall,
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "missing_cells": missing_cells,
        "duplicate_rows": dup_rows,
    }


def generate_html_report(df: pd.DataFrame, quality: dict, run_id: str) -> str:
    img_missing = plot_missing_values(df)
    img_dist = plot_distributions(df)
    img_corr = plot_correlation(df)
    img_outliers = plot_outliers(df)

    def img_tag(b64: str) -> str:
        return f'<img src="data:image/png;base64,{b64}" style="max-width:100%;border-radius:8px;">' if b64 else "<p style='color:#8B949E'>No data to display.</p>"

    score = quality["overall_score"]
    score_color = "#4CAF50" if score >= 80 else "#FF9800" if score >= 60 else "#F44336"

    stats = df.describe().T.round(3)
    stats_html = stats.to_html(classes="table", border=0)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Data Quality Report — Teen Mental Health Pipeline</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: #0D1117; color: #E6EDF3; font-family: 'Segoe UI', system-ui, sans-serif; padding: 24px; }}
  h1 {{ font-size: 28px; font-weight: 700; color: #58A6FF; border-bottom: 1px solid #30363D; padding-bottom: 12px; margin-bottom: 20px; }}
  h2 {{ font-size: 18px; color: #79C0FF; margin: 28px 0 12px; }}
  .meta {{ color: #8B949E; font-size: 13px; margin-bottom: 20px; }}
  .scorecard {{ display: flex; gap: 16px; flex-wrap: wrap; margin: 20px 0; }}
  .score-card {{ background: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 18px 24px; flex: 1; min-width: 150px; text-align: center; }}
  .score-card .value {{ font-size: 32px; font-weight: 800; }}
  .score-card .label {{ font-size: 12px; color: #8B949E; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.05em; }}
  .overall {{ border: 2px solid {score_color}; }}
  .section {{ background: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 20px; margin-bottom: 20px; }}
  .table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  .table th {{ background: #21262D; color: #79C0FF; padding: 8px 12px; text-align: left; border-bottom: 1px solid #30363D; }}
  .table td {{ padding: 7px 12px; border-bottom: 1px solid #21262D; color: #C9D1D9; }}
  .table tr:hover td {{ background: #1C2128; }}
  .badge {{ display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; }}
  .badge-green {{ background: #0D4429; color: #3FB950; }}
  .badge-red {{ background: #4B1818; color: #F85149; }}
</style>
</head>
<body>
<h1>📊 Data Quality Report</h1>
<p class="meta">Run ID: {run_id} &nbsp;|&nbsp; Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} &nbsp;|&nbsp; Dataset: Teen Mental Health</p>

<div class="scorecard">
  <div class="score-card overall"><div class="value" style="color:{score_color}">{score}</div><div class="label">Overall Score</div></div>
  <div class="score-card"><div class="value" style="color:#4CAF50">{quality['completeness']}%</div><div class="label">Completeness</div></div>
  <div class="score-card"><div class="value" style="color:#2196F3">{quality['uniqueness']}%</div><div class="label">Uniqueness</div></div>
  <div class="score-card"><div class="value" style="color:#FF9800">{quality['validity']}%</div><div class="label">Validity</div></div>
  <div class="score-card"><div class="value">{quality['total_rows']}</div><div class="label">Total Rows</div></div>
  <div class="score-card"><div class="value">{quality['total_columns']}</div><div class="label">Columns</div></div>
  <div class="score-card"><div class="value" style="color:#F44336">{quality['missing_cells']}</div><div class="label">Missing Cells</div></div>
  <div class="score-card"><div class="value" style="color:#F44336">{quality['duplicate_rows']}</div><div class="label">Duplicate Rows</div></div>
</div>

<h2>🔍 Missing Value Analysis</h2>
<div class="section">{img_tag(img_missing)}</div>

<h2>📈 Feature Distributions</h2>
<div class="section">{img_tag(img_dist)}</div>

<h2>🔗 Correlation Matrix</h2>
<div class="section">{img_tag(img_corr)}</div>

<h2>📦 Outlier Detection</h2>
<div class="section">{img_tag(img_outliers)}</div>

<h2>📋 Descriptive Statistics</h2>
<div class="section" style="overflow-x:auto;">{stats_html}</div>

<p style="color:#30363D;font-size:11px;margin-top:30px;text-align:center;">Generated by Teen Mental Health Pipeline — Data Quality Report Generator</p>
</body>
</html>"""
    return html


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> str:
    rid = run_id or datetime.now().strftime("%Y%m%d_%H%M%S")
    quality = compute_quality_metrics(df)
    logger.info(f"Quality metrics: {quality}")

    html = generate_html_report(df, quality, rid)
    out_path = os.path.join(REPORTS_DIR, f"data_quality_report_{rid}.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    json_path = os.path.join(REPORTS_DIR, "latest_quality_metrics.json")
    with open(json_path, "w") as f:
        json.dump({"run_id": rid, "timestamp": datetime.now().isoformat(), **quality}, f, indent=2)

    logger.info(f"Data quality report saved: {out_path}")
    return out_path
