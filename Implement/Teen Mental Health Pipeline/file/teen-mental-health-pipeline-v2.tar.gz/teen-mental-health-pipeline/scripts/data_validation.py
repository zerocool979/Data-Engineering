"""
data_validation.py - Data Validation Module
Detects missing values, duplicates, invalid ranges, and generates a JSON report.
"""

import os
import json
from datetime import datetime
from typing import Optional
import pandas as pd
import numpy as np

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end

logger = get_logger("data_validation")

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "outputs")
os.makedirs(REPORTS_DIR, exist_ok=True)

# Business rules for numeric range validation
VALIDATION_RULES = {
    "age": {"min": 10, "max": 25},
    "daily_social_media_hours": {"min": 0, "max": 24},
    "sleep_hours": {"min": 0, "max": 24},
    "screen_time_before_sleep": {"min": 0, "max": 24},
    "academic_performance": {"min": 0.0, "max": 4.0},
    "physical_activity": {"min": 0, "max": 24},
    "stress_level": {"min": 1, "max": 10},
    "anxiety_level": {"min": 1, "max": 10},
    "addiction_level": {"min": 1, "max": 10},
    "depression_label": {"min": 0, "max": 1},
}


def check_missing_values(df: pd.DataFrame) -> dict:
    missing = df.isnull().sum()
    pct = (missing / len(df) * 100).round(2)
    result = {
        col: {"count": int(missing[col]), "pct": float(pct[col])}
        for col in df.columns
        if missing[col] > 0
    }
    total = int(df.isnull().sum().sum())
    logger.info(f"Missing values: {total} total cells affected in {len(result)} columns")
    return {"per_column": result, "total_missing_cells": total}


def check_duplicates(df: pd.DataFrame) -> dict:
    n_dup = int(df.duplicated().sum())
    logger.info(f"Duplicate rows detected: {n_dup}")
    return {"count": n_dup, "pct": round(n_dup / len(df) * 100, 2)}


def check_ranges(df: pd.DataFrame) -> dict:
    violations = {}
    for col, rules in VALIDATION_RULES.items():
        if col not in df.columns:
            continue
        numeric = pd.to_numeric(df[col], errors="coerce")
        out_of_range = (
            (numeric < rules["min"]) | (numeric > rules["max"])
        ).sum()
        null_after_cast = numeric.isnull().sum() - df[col].isnull().sum()

        if out_of_range > 0 or null_after_cast > 0:
            violations[col] = {
                "out_of_range": int(out_of_range),
                "non_numeric": int(null_after_cast),
                "min_allowed": rules["min"],
                "max_allowed": rules["max"],
                "actual_min": float(numeric.min()) if not numeric.isna().all() else None,
                "actual_max": float(numeric.max()) if not numeric.isna().all() else None,
            }

    logger.info(f"Range violations found in {len(violations)} column(s)")
    return violations


def check_outliers(df: pd.DataFrame) -> dict:
    """IQR-based outlier detection for numeric columns."""
    outliers = {}
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        n_out = int(((df[col] < lower) | (df[col] > upper)).sum())
        if n_out > 0:
            outliers[col] = {
                "count": n_out,
                "pct": round(n_out / len(df) * 100, 2),
                "lower_fence": round(lower, 3),
                "upper_fence": round(upper, 3),
            }
    logger.info(f"Outliers detected in {len(outliers)} column(s)")
    return outliers


def check_cardinality(df: pd.DataFrame) -> dict:
    """Report unique value counts for categorical columns."""
    cat_cols = df.select_dtypes(include=["object"]).columns
    return {
        col: {"unique_values": int(df[col].nunique()), "top_5": df[col].value_counts().head(5).to_dict()}
        for col in cat_cols
    }


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> dict:
    log_pipeline_start(logger, "data_validation")
    success = False
    report = {}

    try:
        report = {
            "run_id": run_id,
            "timestamp": datetime.now().isoformat(),
            "total_rows": len(df),
            "total_columns": len(df.columns),
            "missing_values": check_missing_values(df),
            "duplicates": check_duplicates(df),
            "range_violations": check_ranges(df),
            "outliers": check_outliers(df),
            "cardinality": check_cardinality(df),
            "overall_quality_score": None,  # computed below
        }

        # Simple quality score: 100 minus weighted penalties
        total_cells = len(df) * len(df.columns)
        missing_pct = report["missing_values"]["total_missing_cells"] / total_cells * 100
        dup_pct = report["duplicates"]["pct"]
        violations = sum(
            v["out_of_range"] for v in report["range_violations"].values()
        ) / len(df) * 100
        quality_score = max(0.0, round(100 - missing_pct * 2 - dup_pct * 1.5 - violations, 1))
        report["overall_quality_score"] = quality_score
        logger.info(f"Data Quality Score: {quality_score}/100")

        out_path = os.path.join(REPORTS_DIR, "data_validation_report.json")
        with open(out_path, "w") as f:
            json.dump(report, f, indent=2, default=str)
        logger.info(f"Validation report saved: {out_path}")

        success = True
    except Exception as e:
        logger.error(f"Validation FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "data_validation", success)

    return report


if __name__ == "__main__":
    import sys
    base = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base, "data", "raw", "Teen_Mental_Health_Dataset.csv")
    df = pd.read_csv(path)
    run(df)
