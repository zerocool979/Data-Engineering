"""
logger.py - Centralized Logging System
Handles pipeline execution logs, errors, warnings with rotation.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from datetime import datetime

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "pipeline.log")


def get_logger(name: str = "pipeline") -> logging.Logger:
    """Return a configured logger with both file and console handlers."""
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger  # Avoid duplicate handlers

    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Rotating file handler (5MB max, keep 3 backups)
    file_handler = RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


def log_pipeline_start(logger: logging.Logger, module: str) -> None:
    logger.info(f"{'='*50}")
    logger.info(f"MODULE START: {module.upper()} — {datetime.now().isoformat()}")
    logger.info(f"{'='*50}")


def log_pipeline_end(logger: logging.Logger, module: str, success: bool = True) -> None:
    status = "SUCCESS" if success else "FAILED"
    logger.info(f"MODULE END: {module.upper()} — {status} — {datetime.now().isoformat()}")
    logger.info(f"{'='*50}")
