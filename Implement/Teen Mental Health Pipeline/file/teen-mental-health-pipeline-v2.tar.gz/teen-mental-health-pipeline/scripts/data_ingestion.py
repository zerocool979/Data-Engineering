"""
data_ingestion.py - Data Ingestion Module
Loads, validates schema, and stores raw data with versioning.
"""

import os
import shutil
import pandas as pd
from datetime import datetime
from typing import Optional

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end
from scripts.retry import retry
from scripts.data_versioning import snapshot

logger = get_logger("data_ingestion")

RAW_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "raw")
REQUIRED_COLUMNS = {
    "age", "gender", "daily_social_media_hours", "platform_usage",
    "sleep_hours", "screen_time_before_sleep", "academic_performance",
    "physical_activity", "social_interaction_level", "stress_level",
    "anxiety_level", "addiction_level", "depression_label",
}

os.makedirs(RAW_DIR, exist_ok=True)


@retry(max_attempts=3, delay=1.0, backoff=2.0, exceptions=(OSError, pd.errors.ParserError))
def load_csv(filepath: str) -> pd.DataFrame:
    """Load CSV file into DataFrame with retry logic."""
    logger.info(f"Loading CSV: {filepath}")
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")
    df = pd.read_csv(filepath)
    logger.info(f"Loaded {len(df)} rows × {len(df.columns)} columns")
    return df


def validate_schema(df: pd.DataFrame) -> bool:
    """Validate required columns are present."""
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        logger.error(f"Schema validation FAILED. Missing columns: {missing}")
        return False
    logger.info("Schema validation PASSED.")
    return True


def save_raw_copy(df: pd.DataFrame, source_path: str, run_id: str) -> str:
    """Save raw data copy with timestamp."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(RAW_DIR, f"raw_{ts}.csv")
    df.to_csv(dest, index=False)
    logger.info(f"Raw copy saved: {dest}")
    return dest


def run(source_path: str, run_id: Optional[str] = None) -> Optional[pd.DataFrame]:
    """
    Run the data ingestion module.

    Args:
        source_path: Path to the input CSV file.
        run_id: Optional run identifier for versioning.

    Returns:
        Loaded DataFrame or None on failure.
    """
    log_pipeline_start(logger, "data_ingestion")
    success = False
    df = None

    try:
        df = load_csv(source_path)

        if not validate_schema(df):
            raise ValueError("Schema validation failed — aborting ingestion.")

        logger.info(f"Columns: {list(df.columns)}")
        logger.info(f"Data types:\n{df.dtypes}")
        logger.info(f"Memory usage: {df.memory_usage(deep=True).sum() / 1024:.1f} KB")

        save_raw_copy(df, source_path, run_id or "manual")
        snapshot(df, stage="raw", description="Initial ingestion", run_id=run_id)

        success = True
        logger.info("Data ingestion completed successfully.")
    except Exception as e:
        logger.error(f"Data ingestion FAILED: {e}", exc_info=True)
        raise

    finally:
        log_pipeline_end(logger, "data_ingestion", success)

    return df


if __name__ == "__main__":
    base = os.path.dirname(os.path.dirname(__file__))
    src = os.path.join(base, "data", "raw", "Teen_Mental_Health_Dataset.csv")
    run(src)
