"""
run_pipeline.py - Pipeline Orchestration
Runs all modules sequentially with error handling, retry logic, versioning, and alerting.
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from scripts.logger import get_logger
from scripts.retry import retry

logger = get_logger("run_pipeline")

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DEFAULT_SOURCE = os.path.join(BASE_DIR, "data", "raw", "Teen_Mental_Health_Dataset.csv")


def _step(name: str, fn, *args, **kwargs):
    """Execute a pipeline step with timing, error capture, and logging."""
    logger.info(f"\n{'▶'*3} STEP: {name}")
    t0 = time.time()
    try:
        result = fn(*args, **kwargs)
        elapsed = time.time() - t0
        logger.info(f"✅ {name} completed in {elapsed:.2f}s")
        return result, True
    except Exception as e:
        elapsed = time.time() - t0
        logger.error(f"❌ {name} FAILED after {elapsed:.2f}s: {e}", exc_info=True)
        return None, False


def run_full_pipeline(
    source_path: str = DEFAULT_SOURCE,
    run_id: Optional[str] = None,
    skip_on_failure: bool = False,
) -> dict:
    """
    Execute all pipeline modules in sequence.

    Args:
        source_path: Path to input CSV.
        run_id: Unique run identifier.
        skip_on_failure: If True, continue pipeline even if a step fails.

    Returns:
        Summary dict with step statuses and timing.
    """
    run_id = run_id or f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    pipeline_start = time.time()
    summary = {
        "run_id": run_id,
        "started_at": datetime.now().isoformat(),
        "source": source_path,
        "steps": {},
        "success": False,
    }

    logger.info(f"\n{'='*60}")
    logger.info(f"PIPELINE START — run_id={run_id}")
    logger.info(f"Source: {source_path}")
    logger.info(f"{'='*60}")

    df = None
    all_metrics = {}

    # ─── 1. INGESTION ──────────────────────────────────────────
    from scripts import data_ingestion
    df, ok = _step("Data Ingestion", data_ingestion.run, source_path, run_id)
    summary["steps"]["ingestion"] = ok
    if not ok and not skip_on_failure:
        summary["error"] = "Ingestion failed"
        return _finalize(summary, pipeline_start)

    # ─── 2. VALIDATION ─────────────────────────────────────────
    from scripts import data_validation
    validation_report, ok = _step("Data Validation", data_validation.run, df, run_id)
    summary["steps"]["validation"] = ok
    if not ok and not skip_on_failure:
        return _finalize(summary, pipeline_start)

    # ─── 2b. DATA QUALITY REPORT ───────────────────────────────
    from scripts import data_quality_report
    report_path, ok = _step("Quality Report", data_quality_report.run, df, run_id)
    summary["steps"]["quality_report"] = ok
    summary["quality_report_path"] = report_path

    # ─── 3. CLEANING ───────────────────────────────────────────
    from scripts import data_cleaning
    clean_df, ok = _step("Data Cleaning", data_cleaning.run, df, run_id)
    summary["steps"]["cleaning"] = ok
    if not ok and not skip_on_failure:
        return _finalize(summary, pipeline_start)

    # ─── 4. FEATURE ENGINEERING ────────────────────────────────
    from scripts import feature_engineering
    feature_df, ok = _step("Feature Engineering", feature_engineering.run, clean_df, run_id)
    summary["steps"]["feature_engineering"] = ok
    if not ok and not skip_on_failure:
        return _finalize(summary, pipeline_start)

    # ─── 5. RISK SCORING ───────────────────────────────────────
    from scripts import risk_scoring
    risk_df, ok = _step("Risk Scoring", risk_scoring.run, feature_df, run_id)
    summary["steps"]["risk_scoring"] = ok
    if not ok and not skip_on_failure:
        return _finalize(summary, pipeline_start)

    # ─── 5b. ALERT CHECK ───────────────────────────────────────
    from scripts import alert_system
    if risk_df is not None:
        alerts = alert_system.check_risk_distribution(risk_df, run_id)
        if validation_report:
            missing_pct = (
                validation_report.get("missing_values", {}).get("total_missing_cells", 0)
                / max(len(df) * len(df.columns), 1) * 100
            )
            quality_score = validation_report.get("overall_quality_score", 100)
            alerts += alert_system.check_data_quality(quality_score, missing_pct, run_id)
        summary["alerts_raised"] = len(alerts)

    # ─── 6. DATABASE STORAGE ───────────────────────────────────
    from scripts import database
    _, ok = _step("Database Storage", database.run, clean_df, feature_df, risk_df, run_id)
    summary["steps"]["database"] = ok

    # ─── 7. MODEL TRAINING ─────────────────────────────────────
    from scripts import train_model
    train_result, ok = _step("Model Training", train_model.run, feature_df, run_id)
    summary["steps"]["model_training"] = ok
    if ok and train_result:
        _, all_metrics, _ = train_result
        summary["model_metrics"] = {k: {"f1": v.get("f1"), "accuracy": v.get("accuracy")} for k, v in all_metrics.items()}

        # Alert on model performance
        model_alerts = alert_system.check_model_performance(all_metrics, run_id)
        summary["alerts_raised"] = summary.get("alerts_raised", 0) + len(model_alerts)

        # Store metrics in database
        database.store_model_metrics(all_metrics, run_id)

    # ─── 8. PREDICTION ─────────────────────────────────────────
    from scripts import predict
    pred_result, ok = _step("Prediction", predict.run, feature_df, run_id)
    summary["steps"]["prediction"] = ok
    if ok and pred_result is not None:
        summary["predictions"] = {
            "total": len(pred_result),
            "high_risk": int((pred_result["predicted_label"] == 1).sum()),
        }

    # ─── FINALIZE ──────────────────────────────────────────────
    all_ok = all(summary["steps"].values())
    summary["success"] = all_ok

    # Save run summary
    out_path = os.path.join(BASE_DIR, "data", "outputs", f"pipeline_summary_{run_id}.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, default=str)

    return _finalize(summary, pipeline_start, out_path)


def _finalize(summary: dict, t0: float, out_path: str = None) -> dict:
    elapsed = time.time() - t0
    summary["completed_at"] = datetime.now().isoformat()
    summary["total_duration_seconds"] = round(elapsed, 2)

    status = "✅ SUCCESS" if summary.get("success") else "❌ PARTIAL/FAILED"
    logger.info(f"\n{'='*60}")
    logger.info(f"PIPELINE {status} — run_id={summary['run_id']}")
    logger.info(f"Duration: {elapsed:.2f}s")
    logger.info(f"Steps: {summary['steps']}")
    if out_path:
        logger.info(f"Summary: {out_path}")
    logger.info(f"{'='*60}\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Teen Mental Health Pipeline Runner")
    parser.add_argument("--source", default=DEFAULT_SOURCE, help="Path to CSV data source")
    parser.add_argument("--run-id", help="Custom run identifier")
    parser.add_argument("--skip-on-failure", action="store_true", help="Continue pipeline even if a step fails")
    args = parser.parse_args()

    result = run_full_pipeline(
        source_path=args.source,
        run_id=args.run_id,
        skip_on_failure=args.skip_on_failure,
    )
    sys.exit(0 if result.get("success") else 1)
