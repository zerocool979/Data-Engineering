"""
database.py - SQLite Database Storage
Stores clean data, features, risk scores, and predictions with run tracking.
"""

import os
import sqlite3
import pandas as pd
from datetime import datetime
from typing import Optional
from contextlib import contextmanager

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end
from scripts.retry import retry

logger = get_logger("database")

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "mental_health.db")


@contextmanager
def get_connection():
    """Context manager for SQLite connection."""
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL;")  # Better concurrency
    conn.execute("PRAGMA foreign_keys=ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _create_tables(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS pipeline_runs (
            run_id TEXT PRIMARY KEY,
            started_at TEXT,
            completed_at TEXT,
            status TEXT,
            rows_processed INTEGER,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS clean_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            age INTEGER,
            gender TEXT,
            daily_social_media_hours REAL,
            platform_usage TEXT,
            sleep_hours REAL,
            screen_time_before_sleep REAL,
            academic_performance REAL,
            physical_activity REAL,
            social_interaction_level TEXT,
            stress_level INTEGER,
            anxiety_level INTEGER,
            addiction_level INTEGER,
            depression_label INTEGER
        );

        CREATE TABLE IF NOT EXISTS feature_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            screen_sleep_ratio REAL,
            stress_activity_ratio REAL,
            social_sleep_gap REAL,
            mental_risk_index REAL,
            behavioral_profile TEXT,
            social_interaction_encoded INTEGER,
            gender_encoded INTEGER
        );

        CREATE TABLE IF NOT EXISTS risk_scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            risk_score REAL,
            risk_tier TEXT
        );

        CREATE TABLE IF NOT EXISTS model_performance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            model_name TEXT,
            accuracy REAL,
            precision_score REAL,
            recall_score REAL,
            f1_score REAL,
            trained_at TEXT
        );

        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            predicted_label INTEGER,
            predicted_probability REAL,
            model_used TEXT,
            predicted_at TEXT
        );
    """)
    logger.info("Database tables created/verified.")


@retry(max_attempts=3, delay=1.0, exceptions=(sqlite3.OperationalError,))
def store_dataframe(df: pd.DataFrame, table: str, run_id: str) -> int:
    """Insert a DataFrame into a SQLite table, adding run_id column."""
    df = df.copy()
    df["run_id"] = run_id
    with get_connection() as conn:
        df.to_sql(table, conn, if_exists="append", index=False, method="multi")
    logger.info(f"Stored {len(df)} rows into '{table}' for run_id={run_id}")
    return len(df)


def log_run(run_id: str, status: str, rows: int = 0, notes: str = "") -> None:
    with get_connection() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO pipeline_runs
               (run_id, started_at, completed_at, status, rows_processed, notes)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (run_id, datetime.now().isoformat(), datetime.now().isoformat(), status, rows, notes),
        )
    logger.info(f"Pipeline run logged: run_id={run_id}, status={status}")


def store_model_metrics(metrics: dict, run_id: str) -> None:
    with get_connection() as conn:
        for model_name, m in metrics.items():
            conn.execute(
                """INSERT INTO model_performance
                   (run_id, model_name, accuracy, precision_score, recall_score, f1_score, trained_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (run_id, model_name, m.get("accuracy"), m.get("precision"),
                 m.get("recall"), m.get("f1"), datetime.now().isoformat()),
            )
    logger.info(f"Model metrics stored for {list(metrics.keys())}")


def query(sql: str, params: tuple = ()) -> pd.DataFrame:
    with get_connection() as conn:
        return pd.read_sql_query(sql, conn, params=params)


def run(
    clean_df: pd.DataFrame,
    feature_df: pd.DataFrame,
    risk_df: pd.DataFrame,
    run_id: str,
) -> None:
    log_pipeline_start(logger, "database")
    success = False

    try:
        with get_connection() as conn:
            _create_tables(conn)

        # Select only known schema columns to avoid mismatch
        clean_cols = [
            "age", "gender", "daily_social_media_hours", "platform_usage", "sleep_hours",
            "screen_time_before_sleep", "academic_performance", "physical_activity",
            "social_interaction_level", "stress_level", "anxiety_level",
            "addiction_level", "depression_label",
        ]
        feat_cols = [
            "screen_sleep_ratio", "stress_activity_ratio", "social_sleep_gap",
            "mental_risk_index", "behavioral_profile", "social_interaction_encoded", "gender_encoded",
        ]
        risk_cols = ["risk_score", "risk_tier"]

        store_dataframe(clean_df[[c for c in clean_cols if c in clean_df.columns]], "clean_data", run_id)
        store_dataframe(feature_df[[c for c in feat_cols if c in feature_df.columns]], "feature_data", run_id)
        store_dataframe(risk_df[[c for c in risk_cols if c in risk_df.columns]], "risk_scores", run_id)
        log_run(run_id, "SUCCESS", rows=len(clean_df))

        success = True
    except Exception as e:
        logger.error(f"Database storage FAILED: {e}", exc_info=True)
        log_run(run_id, "FAILED", notes=str(e))
        raise
    finally:
        log_pipeline_end(logger, "database", success)
