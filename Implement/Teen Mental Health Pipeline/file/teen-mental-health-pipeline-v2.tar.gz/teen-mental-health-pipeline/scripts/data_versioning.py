"""
data_versioning.py - Data Versioning System
Tracks every dataset transformation with SHA256 checksums,
timestamps, and metadata for full reproducibility.
"""

import os
import json
import hashlib
import shutil
from datetime import datetime
from typing import Optional
import pandas as pd

from scripts.logger import get_logger

logger = get_logger("data_versioning")

VERSIONS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "versions")
VERSION_INDEX = os.path.join(VERSIONS_DIR, "version_index.json")

os.makedirs(VERSIONS_DIR, exist_ok=True)


def _sha256(filepath: str) -> str:
    """Compute SHA256 checksum of a file."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_index() -> dict:
    """Load the version index from disk."""
    if os.path.exists(VERSION_INDEX):
        with open(VERSION_INDEX, "r") as f:
            return json.load(f)
    return {"versions": [], "latest": {}}


def _save_index(index: dict) -> None:
    """Persist the version index to disk."""
    with open(VERSION_INDEX, "w") as f:
        json.dump(index, f, indent=2)


def snapshot(
    df: pd.DataFrame,
    stage: str,
    description: str = "",
    run_id: Optional[str] = None,
) -> dict:
    """
    Save a versioned snapshot of a DataFrame.

    Args:
        df: The DataFrame to snapshot.
        stage: Pipeline stage name (e.g., 'raw', 'cleaned', 'features').
        description: Human-readable description of changes.
        run_id: Optional pipeline run identifier.

    Returns:
        Version metadata dict.
    """
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_label = run_id or ts
    filename = f"{stage}_{run_label}.csv"
    filepath = os.path.join(VERSIONS_DIR, filename)

    df.to_csv(filepath, index=False)
    checksum = _sha256(filepath)

    meta = {
        "version_id": f"{stage}_{run_label}",
        "stage": stage,
        "timestamp": datetime.now().isoformat(),
        "run_id": run_id,
        "filename": filename,
        "filepath": filepath,
        "rows": len(df),
        "columns": len(df.columns),
        "checksum_sha256": checksum,
        "description": description,
    }

    index = _load_index()
    index["versions"].append(meta)
    index["latest"][stage] = meta
    _save_index(index)

    logger.info(
        f"[versioning] Snapshot saved — stage={stage}, rows={len(df)}, "
        f"checksum={checksum[:12]}..., file={filename}"
    )
    return meta


def get_latest(stage: str) -> Optional[dict]:
    """Return metadata for the latest snapshot of a given stage."""
    index = _load_index()
    return index["latest"].get(stage)


def load_latest(stage: str) -> Optional[pd.DataFrame]:
    """Load the latest versioned DataFrame for a stage."""
    meta = get_latest(stage)
    if meta and os.path.exists(meta["filepath"]):
        logger.info(f"[versioning] Loading latest '{stage}' version: {meta['filename']}")
        return pd.read_csv(meta["filepath"])
    logger.warning(f"[versioning] No snapshot found for stage='{stage}'")
    return None


def list_versions(stage: Optional[str] = None) -> list:
    """List all versions, optionally filtered by stage."""
    index = _load_index()
    versions = index["versions"]
    if stage:
        versions = [v for v in versions if v["stage"] == stage]
    return versions


def rollback(stage: str, version_id: str) -> Optional[pd.DataFrame]:
    """
    Roll back to a specific version of a stage.

    Args:
        stage: Pipeline stage name.
        version_id: The version_id to roll back to.

    Returns:
        DataFrame from the specified version.
    """
    index = _load_index()
    match = next(
        (v for v in index["versions"] if v["version_id"] == version_id), None
    )
    if not match:
        logger.error(f"[versioning] Version '{version_id}' not found.")
        return None

    df = pd.read_csv(match["filepath"])
    # Update latest pointer to rolled-back version
    index["latest"][stage] = match
    _save_index(index)
    logger.info(f"[versioning] Rolled back '{stage}' to version '{version_id}'")
    return df


def diff_versions(version_id_a: str, version_id_b: str) -> dict:
    """
    Compare two versions: row/column counts and checksum differences.

    Returns:
        Dict with comparison stats.
    """
    index = _load_index()

    def find(vid):
        return next((v for v in index["versions"] if v["version_id"] == vid), None)

    a, b = find(version_id_a), find(version_id_b)
    if not a or not b:
        return {"error": "One or both version IDs not found"}

    return {
        "version_a": version_id_a,
        "version_b": version_id_b,
        "row_diff": b["rows"] - a["rows"],
        "col_diff": b["columns"] - a["columns"],
        "same_checksum": a["checksum_sha256"] == b["checksum_sha256"],
        "a_checksum": a["checksum_sha256"],
        "b_checksum": b["checksum_sha256"],
        "a_timestamp": a["timestamp"],
        "b_timestamp": b["timestamp"],
    }
