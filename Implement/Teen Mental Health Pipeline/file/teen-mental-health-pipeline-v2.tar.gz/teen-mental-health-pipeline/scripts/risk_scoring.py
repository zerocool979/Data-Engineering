"""
risk_scoring.py - Risk Score Generator
Generates 0–100 risk scores using rule-based and index-based logic.
"""

import os
import pandas as pd
import numpy as np
from typing import Optional

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end

logger = get_logger("risk_scoring")

OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "outputs")
os.makedirs(OUTPUTS_DIR, exist_ok=True)


def compute_base_score(row: pd.Series) -> float:
    """
    Rule-based risk scoring (0–100).
    Each behavioral factor contributes a weighted penalty.
    """
    score = 0.0

    # Social media overuse
    sm = float(row.get("daily_social_media_hours", 0))
    if sm > 8:
        score += 25
    elif sm > 6:
        score += 18
    elif sm > 4:
        score += 10

    # Sleep deprivation
    sl = float(row.get("sleep_hours", 8))
    if sl < 5:
        score += 25
    elif sl < 6:
        score += 18
    elif sl < 7:
        score += 10

    # Stress
    stress = float(row.get("stress_level", 5))
    if stress >= 8:
        score += 20
    elif stress >= 6:
        score += 12
    elif stress >= 4:
        score += 6

    # Anxiety
    anxiety = float(row.get("anxiety_level", 5))
    if anxiety >= 8:
        score += 15
    elif anxiety >= 6:
        score += 9

    # Addiction
    addiction = float(row.get("addiction_level", 5))
    if addiction >= 8:
        score += 10
    elif addiction >= 6:
        score += 6

    # Low physical activity (protective factor missing)
    pa = float(row.get("physical_activity", 1))
    if pa < 0.5:
        score += 5
    elif pa < 1.0:
        score += 2

    return min(score, 100.0)


def apply_compound_rules(df: pd.DataFrame) -> pd.Series:
    """
    Add compound rule bonuses: co-occurrence of multiple risk factors.
    """
    bonus = pd.Series(0.0, index=df.index)

    # Triple threat: high social media + low sleep + high stress
    triple = (
        (df["daily_social_media_hours"] > 6)
        & (df["sleep_hours"] < 6)
        & (df["stress_level"] > 7)
    )
    bonus[triple] += 10

    # Screen before sleep + anxiety
    screen_anxiety = (
        (df["screen_time_before_sleep"] > 2)
        & (df["anxiety_level"] >= 7)
    )
    bonus[screen_anxiety] += 5

    return bonus.clip(0, 20)  # cap compound bonus at 20


def assign_risk_tier(score: float) -> str:
    if score >= 75:
        return "CRITICAL"
    elif score >= 55:
        return "HIGH"
    elif score >= 35:
        return "MODERATE"
    elif score >= 15:
        return "LOW"
    else:
        return "MINIMAL"


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> pd.DataFrame:
    log_pipeline_start(logger, "risk_scoring")
    success = False

    try:
        base_scores = df.apply(compute_base_score, axis=1)
        compound_bonus = apply_compound_rules(df)

        # Also blend with mental_risk_index if available
        if "mental_risk_index" in df.columns:
            index_score = df["mental_risk_index"] * 100
            final_scores = (0.7 * base_scores + 0.2 * compound_bonus + 0.1 * index_score).clip(0, 100)
        else:
            final_scores = (base_scores + compound_bonus).clip(0, 100)

        df["risk_score"] = final_scores.round(1)
        df["risk_tier"] = df["risk_score"].apply(assign_risk_tier)

        tier_counts = df["risk_tier"].value_counts().to_dict()
        logger.info(f"Risk tier distribution: {tier_counts}")

        out_path = os.path.join(OUTPUTS_DIR, "risk_scores.csv")
        df[["risk_score", "risk_tier"]].to_csv(out_path, index=False)
        logger.info(f"Risk scores saved: {out_path}")

        # Also save full df with risk for downstream use
        full_path = os.path.join(OUTPUTS_DIR, "data_with_risk.csv")
        df.to_csv(full_path, index=False)

        success = True
    except Exception as e:
        logger.error(f"Risk scoring FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "risk_scoring", success)

    return df
