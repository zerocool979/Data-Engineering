"""
scheduler.py - Daily Automated Run Scheduler
Uses APScheduler for cron-based pipeline execution with retry and logging.
"""

import os
import sys
import json
import signal
from datetime import datetime
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

try:
    from apscheduler.schedulers.blocking import BlockingScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False

from scripts.logger import get_logger
from scripts.retry import retry

logger = get_logger("scheduler")

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "scheduler_config.json")
SCHEDULER_LOG = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "scheduler.log")
os.makedirs(os.path.dirname(SCHEDULER_LOG), exist_ok=True)

DEFAULT_CONFIG = {
    "enabled": True,
    "run_hour": 2,
    "run_minute": 0,
    "timezone": "UTC",
    "source_csv": "data/raw/Teen_Mental_Health_Dataset.csv",
    "max_retries": 3,
    "retry_delay_seconds": 60,
}


def load_config() -> dict:
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return {**DEFAULT_CONFIG, **json.load(f)}
    return DEFAULT_CONFIG


def save_default_config() -> None:
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)
    logger.info(f"Default scheduler config saved: {CONFIG_PATH}")


def _log_scheduler_event(event) -> None:
    if event.exception:
        logger.error(f"Scheduled job FAILED: {event.job_id} — {event.exception}")
    else:
        logger.info(f"Scheduled job completed: {event.job_id}")


@retry(max_attempts=3, delay=30.0, backoff=2.0, exceptions=(Exception,))
def scheduled_pipeline_run() -> None:
    """
    Execute the full pipeline. Called by the scheduler.
    Retries up to 3 times on failure with exponential backoff.
    """
    from scripts.run_pipeline import run_full_pipeline

    run_id = f"scheduled_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    logger.info(f"Scheduler triggered pipeline run: {run_id}")

    config = load_config()
    base = os.path.dirname(os.path.dirname(__file__))
    source = os.path.join(base, config["source_csv"])

    run_full_pipeline(source_path=source, run_id=run_id)

    # Log successful run
    with open(SCHEDULER_LOG, "a") as f:
        f.write(json.dumps({
            "run_id": run_id,
            "status": "SUCCESS",
            "timestamp": datetime.now().isoformat()
        }) + "\n")

    logger.info(f"Scheduled pipeline run completed: {run_id}")


def start_scheduler(run_now: bool = False) -> None:
    """
    Start the APScheduler blocking scheduler.

    Args:
        run_now: If True, trigger one immediate run before scheduling.
    """
    if not APSCHEDULER_AVAILABLE:
        logger.error(
            "APScheduler not installed. Run: pip install apscheduler\n"
            "Alternatively, use run_pipeline.py for manual execution."
        )
        return

    config = load_config()
    if not config.get("enabled", True):
        logger.info("Scheduler is disabled in config. Exiting.")
        return

    scheduler = BlockingScheduler(timezone=config["timezone"])
    scheduler.add_listener(_log_scheduler_event, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

    # Daily cron trigger
    trigger = CronTrigger(
        hour=config["run_hour"],
        minute=config["run_minute"],
        timezone=config["timezone"],
    )
    scheduler.add_job(
        scheduled_pipeline_run,
        trigger=trigger,
        id="daily_pipeline_run",
        name="Teen Mental Health Pipeline — Daily Run",
        max_instances=1,
        coalesce=True,
        misfire_grace_time=3600,  # Allow 1-hour misfire window
    )

    logger.info(
        f"Scheduler started. Daily run at {config['run_hour']:02d}:{config['run_minute']:02d} {config['timezone']}"
    )

    if run_now:
        logger.info("Triggering immediate pipeline run...")
        scheduled_pipeline_run()

    def _shutdown(signum, frame):
        logger.info("Scheduler shutdown signal received.")
        scheduler.shutdown(wait=False)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Scheduler stopped.")


def get_schedule_status() -> dict:
    """Return current scheduler configuration and last run history."""
    config = load_config()
    history = []
    if os.path.exists(SCHEDULER_LOG):
        with open(SCHEDULER_LOG) as f:
            for line in f:
                try:
                    history.append(json.loads(line.strip()))
                except Exception:
                    continue
    return {
        "config": config,
        "last_runs": history[-10:],
        "apscheduler_available": APSCHEDULER_AVAILABLE,
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Teen Mental Health Pipeline Scheduler")
    parser.add_argument("--run-now", action="store_true", help="Trigger immediate run before scheduling")
    parser.add_argument("--init-config", action="store_true", help="Save default config and exit")
    args = parser.parse_args()

    if args.init_config:
        save_default_config()
        print(f"Config saved to {CONFIG_PATH}")
        sys.exit(0)

    start_scheduler(run_now=args.run_now)
