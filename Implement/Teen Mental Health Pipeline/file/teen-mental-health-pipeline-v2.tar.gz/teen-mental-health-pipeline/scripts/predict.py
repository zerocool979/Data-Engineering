"""
predict.py - Prediction Module
Loads trained model and generates risk predictions for new data.
"""

import os
import pickle
import pandas as pd
from datetime import datetime
from typing import Optional, Union

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end

logger = get_logger("predict")

MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "models")
OUTPUTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "outputs")
MODEL_PATH = os.path.join(MODELS_DIR, "risk_model.pkl")

os.makedirs(OUTPUTS_DIR, exist_ok=True)


def load_model() -> dict:
    """Load the saved model bundle."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run train_model.py first.")
    with open(MODEL_PATH, "rb") as f:
        bundle = pickle.load(f)
    logger.info(f"Model loaded: {bundle['model_name']} (trained {bundle['trained_at']})")
    return bundle


def align_features(df: pd.DataFrame, feature_names: list) -> pd.DataFrame:
    """Ensure DataFrame has exactly the expected features in order."""
    missing = [f for f in feature_names if f not in df.columns]
    if missing:
        logger.warning(f"Adding zero-filled columns for missing features: {missing}")
        for col in missing:
            df[col] = 0
    return df[feature_names]


def predict(
    df: pd.DataFrame,
    run_id: Optional[str] = None,
    save: bool = True,
) -> pd.DataFrame:
    """
    Generate predictions for a DataFrame.

    Args:
        df: Input DataFrame (must have feature columns or close approximations).
        run_id: Optional run identifier.
        save: Whether to save prediction_results.csv.

    Returns:
        DataFrame with predicted_label and predicted_probability columns.
    """
    log_pipeline_start(logger, "predict")
    success = False

    try:
        bundle = load_model()
        model = bundle["model"]
        feature_names = bundle["feature_names"]

        X = align_features(df.copy(), feature_names)

        preds = model.predict(X)
        probs = model.predict_proba(X)[:, 1] if hasattr(model, "predict_proba") else [None] * len(X)

        results = df.copy()
        results["predicted_label"] = preds
        results["predicted_probability"] = [round(p, 4) if p is not None else None for p in probs]
        results["risk_flag"] = results["predicted_probability"].apply(
            lambda p: "HIGH_RISK" if p is not None and p >= 0.5 else "LOW_RISK"
        )
        results["predicted_at"] = datetime.now().isoformat()
        results["model_used"] = bundle["model_name"]

        high_risk_count = (results["predicted_label"] == 1).sum()
        logger.info(
            f"Predictions generated: {len(results)} total, {high_risk_count} high-risk "
            f"({high_risk_count/len(results)*100:.1f}%)"
        )

        if save:
            out_path = os.path.join(OUTPUTS_DIR, "prediction_results.csv")
            results.to_csv(out_path, index=False)
            logger.info(f"Prediction results saved: {out_path}")

        success = True
        return results

    except Exception as e:
        logger.error(f"Prediction FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "predict", success)


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> pd.DataFrame:
    return predict(df, run_id=run_id, save=True)


if __name__ == "__main__":
    base = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base, "data", "features", "feature_data.csv")
    df = pd.read_csv(path)
    result = predict(df)
    print(result[["predicted_label", "predicted_probability", "risk_flag"]].head(10))
