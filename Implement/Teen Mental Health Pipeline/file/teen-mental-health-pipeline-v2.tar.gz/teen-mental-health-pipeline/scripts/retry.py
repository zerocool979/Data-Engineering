"""
retry.py - Retry Logic Utility
Provides decorators and helpers for robust error handling with retry logic.
"""

import time
import functools
from typing import Callable, Tuple, Type, Any
from scripts.logger import get_logger

logger = get_logger("retry")


def retry(
    max_attempts: int = 3,
    delay: float = 2.0,
    backoff: float = 2.0,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    on_failure: Callable = None,
):
    """
    Decorator that retries a function on failure with exponential backoff.

    Args:
        max_attempts: Maximum number of retry attempts.
        delay: Initial delay in seconds between retries.
        backoff: Multiplier applied to delay after each retry.
        exceptions: Tuple of exception types to catch and retry on.
        on_failure: Optional callback called when all attempts are exhausted.
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            current_delay = delay
            last_exception = None

            for attempt in range(1, max_attempts + 1):
                try:
                    result = func(*args, **kwargs)
                    if attempt > 1:
                        logger.info(
                            f"[{func.__name__}] Succeeded on attempt {attempt}/{max_attempts}"
                        )
                    return result

                except exceptions as e:
                    last_exception = e
                    logger.warning(
                        f"[{func.__name__}] Attempt {attempt}/{max_attempts} failed: {e}"
                    )

                    if attempt < max_attempts:
                        logger.info(
                            f"[{func.__name__}] Retrying in {current_delay:.1f}s..."
                        )
                        time.sleep(current_delay)
                        current_delay *= backoff
                    else:
                        logger.error(
                            f"[{func.__name__}] All {max_attempts} attempts failed."
                        )
                        if on_failure:
                            on_failure(func.__name__, last_exception)

            raise last_exception

        return wrapper

    return decorator


def safe_execute(func: Callable, *args, default=None, label: str = "", **kwargs) -> Any:
    """
    Execute a function safely, returning default on failure.
    Logs error without raising.
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        name = label or func.__name__
        logger.error(f"[safe_execute] {name} failed: {e}")
        return default
