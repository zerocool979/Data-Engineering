"""
data_cleaning.py - Data Cleaning Module
Handles missing values, duplicates, normalization, and type standardization.
"""

import os
import pandas as pd
import numpy as np
from typing import Optional

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end
from scripts.data_versioning import snapshot

logger = get_logger("data_cleaning")

PROCESSED_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "processed")
os.makedirs(PROCESSED_DIR, exist_ok=True)


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = (
        df.columns.str.strip()
        .str.lower()
        .str.replace(r"[\s\-]", "_", regex=True)
        .str.replace(r"[^\w]", "", regex=True)
    )
    logger.info("Column names normalized.")
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    removed = before - len(df)
    logger.info(f"Removed {removed} duplicate rows. Remaining: {len(df)}")
    return df


def fill_missing_numeric(df: pd.DataFrame) -> pd.DataFrame:
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        n_missing = df[col].isnull().sum()
        if n_missing > 0:
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)
            logger.info(f"  Filled {n_missing} missing values in '{col}' with median={median_val:.3f}")
    return df


def fill_missing_categorical(df: pd.DataFrame) -> pd.DataFrame:
    cat_cols = df.select_dtypes(include=["object"]).columns
    for col in cat_cols:
        n_missing = df[col].isnull().sum()
        if n_missing > 0:
            mode_val = df[col].mode()[0]
            df[col] = df[col].fillna(mode_val)
            logger.info(f"  Filled {n_missing} missing values in '{col}' with mode='{mode_val}'")
    return df


def handle_invalid_ranges(df: pd.DataFrame) -> pd.DataFrame:
    """Clip numeric values to valid ranges."""
    clipping_rules = {
        "daily_social_media_hours": (0, 24),
        "sleep_hours": (0, 24),
        "screen_time_before_sleep": (0, 24),
        "physical_activity": (0, 24),
        "stress_level": (1, 10),
        "anxiety_level": (1, 10),
        "addiction_level": (1, 10),
        "academic_performance": (0.0, 4.0),
    }
    for col, (lo, hi) in clipping_rules.items():
        if col in df.columns:
            before = ((df[col] < lo) | (df[col] > hi)).sum()
            df[col] = df[col].clip(lower=lo, upper=hi)
            if before > 0:
                logger.info(f"  Clipped {before} out-of-range values in '{col}' to [{lo}, {hi}]")
    return df


def standardize_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """Lowercase + strip whitespace for string columns."""
    cat_cols = df.select_dtypes(include=["object"]).columns
    for col in cat_cols:
        df[col] = df[col].str.lower().str.strip()
    logger.info(f"Standardized {len(cat_cols)} categorical column(s).")
    return df


def cast_types(df: pd.DataFrame) -> pd.DataFrame:
    int_cols = ["age", "stress_level", "anxiety_level", "addiction_level", "depression_label"]
    for col in int_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")
    float_cols = ["daily_social_media_hours", "sleep_hours", "screen_time_before_sleep",
                  "academic_performance", "physical_activity"]
    for col in float_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype(float)
    logger.info("Data types cast to appropriate formats.")
    return df


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> pd.DataFrame:
    log_pipeline_start(logger, "data_cleaning")
    success = False

    try:
        logger.info(f"Input shape: {df.shape}")
        df = normalize_column_names(df)
        df = remove_duplicates(df)
        df = fill_missing_numeric(df)
        df = fill_missing_categorical(df)
        df = handle_invalid_ranges(df)
        df = standardize_categoricals(df)
        df = cast_types(df)

        out_path = os.path.join(PROCESSED_DIR, "clean_data.csv")
        df.to_csv(out_path, index=False)
        logger.info(f"Clean data saved: {out_path} ({len(df)} rows)")
        snapshot(df, stage="cleaned", description="After cleaning", run_id=run_id)

        success = True
    except Exception as e:
        logger.error(f"Cleaning FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "data_cleaning", success)

    return df


if __name__ == "__main__":
    base = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base, "data", "raw", "Teen_Mental_Health_Dataset.csv")
    df = pd.read_csv(path)
    run(df)
