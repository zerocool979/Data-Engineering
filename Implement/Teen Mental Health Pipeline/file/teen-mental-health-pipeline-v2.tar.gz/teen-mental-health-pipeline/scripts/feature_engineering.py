"""
feature_engineering.py - Feature Engineering Module
Generates behavioral composite features and mental health indicators.
"""

import os
import pandas as pd
import numpy as np
from typing import Optional

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end
from scripts.data_versioning import snapshot

logger = get_logger("feature_engineering")

FEATURES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "features")
os.makedirs(FEATURES_DIR, exist_ok=True)


def create_ratio_features(df: pd.DataFrame) -> pd.DataFrame:
    """Screen and behavioral ratio features."""
    eps = 1e-6  # prevent division by zero
    df["screen_sleep_ratio"] = (df["daily_social_media_hours"] / (df["sleep_hours"] + eps)).round(4)
    df["stress_activity_ratio"] = (df["stress_level"] / (df["physical_activity"] + eps)).round(4)
    df["social_sleep_gap"] = (df["daily_social_media_hours"] - df["sleep_hours"]).round(4)
    df["screen_before_sleep_pct"] = (
        df["screen_time_before_sleep"] / (df["sleep_hours"] + eps) * 100
    ).round(2)
    logger.info("Ratio features created: screen_sleep_ratio, stress_activity_ratio, social_sleep_gap, screen_before_sleep_pct")
    return df


def create_risk_index(df: pd.DataFrame) -> pd.DataFrame:
    """
    Composite mental risk index combining normalized behavioral signals.
    Weights reflect domain importance (social media > sleep deprivation > stress).
    """
    def norm(series, lo, hi):
        return ((series - lo) / (hi - lo + 1e-6)).clip(0, 1)

    df["mental_risk_index"] = (
        0.30 * norm(df["daily_social_media_hours"], 0, 10)
        + 0.20 * (1 - norm(df["sleep_hours"], 4, 9))          # inverted: less sleep = higher risk
        + 0.20 * norm(df["stress_level"], 1, 10)
        + 0.15 * norm(df["anxiety_level"], 1, 10)
        + 0.10 * norm(df["addiction_level"], 1, 10)
        + 0.05 * (1 - norm(df["physical_activity"], 0, 5))     # inverted: less activity = higher risk
    ).round(4)

    logger.info("mental_risk_index created.")
    return df


def create_behavioral_clusters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rule-based behavioral profile labels for interpretability.
    """
    conditions = [
        (df["daily_social_media_hours"] > 6) & (df["sleep_hours"] < 6),
        (df["physical_activity"] > 1.5) & (df["sleep_hours"] >= 7),
        (df["stress_level"] >= 7) & (df["anxiety_level"] >= 7),
    ]
    choices = ["heavy_user_sleep_deprived", "active_well_rested", "high_stress_anxious"]
    df["behavioral_profile"] = np.select(conditions, choices, default="moderate")
    logger.info("behavioral_profile feature created.")
    return df


def create_categorical_encodings(df: pd.DataFrame) -> pd.DataFrame:
    """Ordinal encode social_interaction_level."""
    interaction_map = {"low": 0, "medium": 1, "high": 2}
    if "social_interaction_level" in df.columns:
        df["social_interaction_encoded"] = df["social_interaction_level"].map(interaction_map).fillna(1)

    if "gender" in df.columns:
        df["gender_encoded"] = (df["gender"] == "female").astype(int)

    platform_dummies = pd.get_dummies(df.get("platform_usage", pd.Series(dtype=str)), prefix="platform")
    df = pd.concat([df, platform_dummies], axis=1)
    logger.info("Categorical encodings applied.")
    return df


def create_age_groups(df: pd.DataFrame) -> pd.DataFrame:
    if "age" in df.columns:
        bins = [0, 13, 15, 17, 19, 25]
        labels = ["<13", "13-15", "15-17", "17-19", "19+"]
        df["age_group"] = pd.cut(df["age"], bins=bins, labels=labels, right=True)
    return df


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> pd.DataFrame:
    log_pipeline_start(logger, "feature_engineering")
    success = False

    try:
        df = create_ratio_features(df)
        df = create_risk_index(df)
        df = create_behavioral_clusters(df)
        df = create_categorical_encodings(df)
        df = create_age_groups(df)

        out_path = os.path.join(FEATURES_DIR, "feature_data.csv")
        df.to_csv(out_path, index=False)
        logger.info(f"Feature data saved: {out_path} ({len(df)} rows, {len(df.columns)} cols)")
        snapshot(df, stage="features", description="After feature engineering", run_id=run_id)

        success = True
    except Exception as e:
        logger.error(f"Feature engineering FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "feature_engineering", success)

    return df
