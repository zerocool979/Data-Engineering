"""
train_model.py - Machine Learning Module
Trains Logistic Regression, Decision Tree, and Random Forest.
Generates model comparison visualizations.
"""

import os
import pickle
import json
from datetime import datetime
from typing import Optional, Tuple, Dict

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
)
from sklearn.pipeline import Pipeline

from scripts.logger import get_logger, log_pipeline_start, log_pipeline_end

logger = get_logger("train_model")

MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "models")
REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports")
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

FEATURE_COLS = [
    "daily_social_media_hours", "sleep_hours", "screen_time_before_sleep",
    "physical_activity", "stress_level", "anxiety_level", "addiction_level",
    "academic_performance", "social_interaction_encoded", "gender_encoded",
    "screen_sleep_ratio", "stress_activity_ratio", "social_sleep_gap",
    "mental_risk_index",
]
TARGET_COL = "depression_label"

MODELS = {
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=1000, random_state=42)),
    ]),
    "Decision Tree": Pipeline([
        ("clf", DecisionTreeClassifier(max_depth=6, random_state=42)),
    ]),
    "Random Forest": Pipeline([
        ("clf", RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42, n_jobs=-1)),
    ]),
}


def prepare_data(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    """Select features and target, drop NaN rows."""
    avail_feats = [c for c in FEATURE_COLS if c in df.columns]
    missing_feats = [c for c in FEATURE_COLS if c not in df.columns]
    if missing_feats:
        logger.warning(f"Missing feature columns (will skip): {missing_feats}")

    df_clean = df[avail_feats + [TARGET_COL]].dropna()
    X = df_clean[avail_feats]
    y = df_clean[TARGET_COL].astype(int)
    logger.info(f"Training data: {X.shape}, Target distribution:\n{y.value_counts().to_dict()}")
    return X, y


def evaluate_model(model, X_test: pd.DataFrame, y_test: pd.Series, name: str) -> dict:
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else None

    metrics = {
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
        "recall": round(recall_score(y_test, y_pred, zero_division=0), 4),
        "f1": round(f1_score(y_test, y_pred, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, y_prob), 4) if y_prob is not None else None,
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    }
    logger.info(f"[{name}] Accuracy={metrics['accuracy']}, F1={metrics['f1']}, AUC={metrics['roc_auc']}")
    return metrics


def plot_model_comparison(all_metrics: Dict[str, dict], run_id: str) -> str:
    """Generate a comprehensive model comparison visualization."""
    models = list(all_metrics.keys())
    metric_names = ["accuracy", "precision", "recall", "f1", "roc_auc"]
    colors = ["#2196F3", "#4CAF50", "#FF5722", "#9C27B0", "#FF9800"]

    fig = plt.figure(figsize=(18, 14), facecolor="#0D1117")
    fig.suptitle(
        "Model Comparison Dashboard\nTeen Mental Health Risk Prediction",
        fontsize=18, fontweight="bold", color="#E6EDF3", y=0.98
    )

    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)
    ax_bar = fig.add_subplot(gs[0, :2])
    ax_radar = fig.add_subplot(gs[0, 2], polar=True)
    ax_cm_lr = fig.add_subplot(gs[1, 0])
    ax_cm_dt = fig.add_subplot(gs[1, 1])
    ax_cm_rf = fig.add_subplot(gs[1, 2])

    # --- Bar chart ---
    x = np.arange(len(metric_names))
    width = 0.25
    for i, (model_name, color) in enumerate(zip(models, colors)):
        vals = [all_metrics[model_name].get(m, 0) or 0 for m in metric_names]
        bars = ax_bar.bar(x + i * width, vals, width, label=model_name, color=color, alpha=0.85, edgecolor="white", linewidth=0.5)
        for bar, val in zip(bars, vals):
            ax_bar.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                        f"{val:.3f}", ha="center", va="bottom", fontsize=7, color="#E6EDF3")

    ax_bar.set_xticks(x + width)
    ax_bar.set_xticklabels([m.replace("_", " ").title() for m in metric_names], color="#E6EDF3")
    ax_bar.set_ylim(0, 1.12)
    ax_bar.set_ylabel("Score", color="#E6EDF3")
    ax_bar.set_title("Performance Metrics by Model", color="#E6EDF3", fontsize=13, pad=10)
    ax_bar.legend(loc="upper right", fontsize=9, framealpha=0.3)
    ax_bar.set_facecolor("#161B22")
    ax_bar.tick_params(colors="#E6EDF3")
    ax_bar.spines[:].set_color("#30363D")

    # --- Radar chart ---
    categories = [m.replace("_", "\n").title() for m in metric_names]
    N = len(categories)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    ax_radar.set_facecolor("#161B22")
    ax_radar.set_theta_offset(np.pi / 2)
    ax_radar.set_theta_direction(-1)
    ax_radar.set_xticks(angles[:-1])
    ax_radar.set_xticklabels(categories, color="#E6EDF3", fontsize=8)
    ax_radar.set_ylim(0, 1)
    ax_radar.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax_radar.set_yticklabels(["0.25", "0.5", "0.75", "1.0"], color="#8B949E", fontsize=7)
    ax_radar.grid(color="#30363D")

    for model_name, color in zip(models, colors):
        vals = [all_metrics[model_name].get(m, 0) or 0 for m in metric_names]
        vals += vals[:1]
        ax_radar.plot(angles, vals, color=color, linewidth=2)
        ax_radar.fill(angles, vals, color=color, alpha=0.1)

    ax_radar.set_title("Performance Radar", color="#E6EDF3", fontsize=11, pad=20)

    # --- Confusion matrices ---
    cm_axes = [ax_cm_lr, ax_cm_dt, ax_cm_rf]
    for ax, model_name in zip(cm_axes, models):
        cm = np.array(all_metrics[model_name]["confusion_matrix"])
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                    cbar=False, linewidths=0.5, linecolor="#30363D",
                    annot_kws={"size": 12, "color": "white"})
        ax.set_facecolor("#161B22")
        ax.set_title(f"Confusion Matrix\n{model_name}", color="#E6EDF3", fontsize=10)
        ax.set_xlabel("Predicted", color="#8B949E")
        ax.set_ylabel("Actual", color="#8B949E")
        ax.tick_params(colors="#E6EDF3")

    out_path = os.path.join(REPORTS_DIR, f"model_comparison_{run_id}.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    logger.info(f"Model comparison chart saved: {out_path}")
    return out_path


def get_feature_importances(model, feature_names: list) -> Optional[dict]:
    """Extract feature importances from tree-based models."""
    clf = model.named_steps.get("clf", model)
    if hasattr(clf, "feature_importances_"):
        importances = clf.feature_importances_
        return dict(sorted(zip(feature_names, importances), key=lambda x: -x[1]))
    return None


def run(df: pd.DataFrame, run_id: Optional[str] = None) -> Tuple[object, dict, list]:
    log_pipeline_start(logger, "train_model")
    success = False
    best_model, all_metrics, feature_names = None, {}, []

    try:
        X, y = prepare_data(df)
        feature_names = list(X.columns)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        best_f1 = -1

        for name, model in MODELS.items():
            logger.info(f"Training {name}...")
            model.fit(X_train, y_train)

            cv_scores = cross_val_score(model, X, y, cv=cv, scoring="f1")
            logger.info(f"[{name}] CV F1: {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")

            metrics = evaluate_model(model, X_test, y_test, name)
            metrics["cv_f1_mean"] = round(cv_scores.mean(), 4)
            metrics["cv_f1_std"] = round(cv_scores.std(), 4)
            all_metrics[name] = metrics

            importances = get_feature_importances(model, feature_names)
            if importances:
                metrics["top_features"] = {k: round(v, 4) for k, v in list(importances.items())[:5]}

            if metrics["f1"] > best_f1:
                best_f1 = metrics["f1"]
                best_model = model
                best_model_name = name

        logger.info(f"Best model: {best_model_name} (F1={best_f1:.4f})")

        # Save best model
        model_path = os.path.join(MODELS_DIR, "risk_model.pkl")
        with open(model_path, "wb") as f:
            pickle.dump({
                "model": best_model,
                "feature_names": feature_names,
                "model_name": best_model_name,
                "trained_at": datetime.now().isoformat(),
                "metrics": all_metrics[best_model_name],
            }, f)
        logger.info(f"Best model saved: {model_path}")

        # Save all metrics JSON
        metrics_path = os.path.join(REPORTS_DIR, "model_metrics.json")
        with open(metrics_path, "w") as f:
            json.dump(all_metrics, f, indent=2, default=str)

        plot_model_comparison(all_metrics, run_id or "latest")
        success = True

    except Exception as e:
        logger.error(f"Model training FAILED: {e}", exc_info=True)
        raise
    finally:
        log_pipeline_end(logger, "train_model", success)

    return best_model, all_metrics, feature_names
