"""
alert_system.py - Risk Alert Notification System
Detects high-risk cases, quality degradation, and pipeline anomalies.
Supports console, file, and (optionally) email/webhook alerts.
"""

import os
import json
import smtplib
import urllib.request
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, List
import pandas as pd

from scripts.logger import get_logger

logger = get_logger("alert_system")

ALERTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "outputs")
os.makedirs(ALERTS_DIR, exist_ok=True)

ALERT_LOG = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "alerts.log")
CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "alert_config.json")


SEVERITY_COLORS = {
    "CRITICAL": "🔴",
    "HIGH": "🟠",
    "MODERATE": "🟡",
    "INFO": "🔵",
}


def _load_config() -> dict:
    """Load alert configuration (email/webhook settings)."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {
        "email_enabled": False,
        "webhook_enabled": False,
        "alert_thresholds": {
            "critical_risk_pct": 20.0,
            "high_risk_pct": 40.0,
            "quality_score_min": 70.0,
            "max_missing_pct": 10.0,
        },
    }


def _write_alert_log(alert: dict) -> None:
    """Append alert to alert log file."""
    with open(ALERT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(alert) + "\n")


def _send_email(subject: str, body: str, config: dict) -> bool:
    """Send email alert using SMTP (optional)."""
    if not config.get("email_enabled"):
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = config["smtp_from"]
        msg["To"] = ", ".join(config["smtp_to"])
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(config["smtp_host"], config.get("smtp_port", 587)) as server:
            server.starttls()
            server.login(config["smtp_user"], config["smtp_password"])
            server.sendmail(config["smtp_from"], config["smtp_to"], msg.as_string())

        logger.info(f"Email alert sent: {subject}")
        return True
    except Exception as e:
        logger.error(f"Email alert FAILED: {e}")
        return False


def _send_webhook(payload: dict, config: dict) -> bool:
    """Send webhook alert (Slack/Teams compatible)."""
    if not config.get("webhook_enabled"):
        return False
    try:
        url = config["webhook_url"]
        data = json.dumps({"text": f"*{payload['severity']}* {payload['title']}\n{payload['message']}"})
        req = urllib.request.Request(
            url, data=data.encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST"
        )
        urllib.request.urlopen(req, timeout=5)
        logger.info(f"Webhook alert sent: {payload['title']}")
        return True
    except Exception as e:
        logger.error(f"Webhook alert FAILED: {e}")
        return False


def raise_alert(
    title: str,
    message: str,
    severity: str = "HIGH",
    run_id: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> dict:
    """
    Raise an alert with console output, log file, and optional notifications.

    Args:
        title: Short alert title.
        message: Detailed alert message.
        severity: CRITICAL | HIGH | MODERATE | INFO
        run_id: Pipeline run identifier.
        metadata: Extra context dict.

    Returns:
        Alert record dict.
    """
    icon = SEVERITY_COLORS.get(severity, "⚪")
    alert = {
        "alert_id": f"{severity}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "severity": severity,
        "title": title,
        "message": message,
        "run_id": run_id,
        "timestamp": datetime.now().isoformat(),
        "metadata": metadata or {},
    }

    # Console output
    print(f"\n{'='*60}")
    print(f"{icon} ALERT [{severity}]: {title}")
    print(f"   {message}")
    if metadata:
        for k, v in metadata.items():
            print(f"   {k}: {v}")
    print(f"   Time: {alert['timestamp']}")
    print(f"{'='*60}\n")

    logger.warning(f"ALERT [{severity}] {title}: {message}")
    _write_alert_log(alert)

    config = _load_config()
    _send_email(f"[{severity}] Teen MH Pipeline: {title}", message, config)
    _send_webhook(alert, config)

    return alert


def check_risk_distribution(df: pd.DataFrame, run_id: Optional[str] = None) -> List[dict]:
    """
    Check risk tier distribution and raise alerts if thresholds exceeded.
    """
    alerts = []
    config = _load_config()
    thresholds = config.get("alert_thresholds", {})

    if "risk_tier" not in df.columns:
        return alerts

    tier_counts = df["risk_tier"].value_counts(normalize=True) * 100

    critical_pct = float(tier_counts.get("CRITICAL", 0))
    high_pct = float(tier_counts.get("HIGH", 0))

    if critical_pct >= thresholds.get("critical_risk_pct", 20):
        a = raise_alert(
            title="CRITICAL Risk Tier Spike Detected",
            message=f"{critical_pct:.1f}% of teens classified as CRITICAL risk (threshold: {thresholds.get('critical_risk_pct', 20)}%)",
            severity="CRITICAL",
            run_id=run_id,
            metadata={"critical_pct": critical_pct, "threshold": thresholds.get("critical_risk_pct", 20)},
        )
        alerts.append(a)

    if high_pct >= thresholds.get("high_risk_pct", 40):
        a = raise_alert(
            title="HIGH Risk Population Elevated",
            message=f"{high_pct:.1f}% of teens in HIGH or above risk tier.",
            severity="HIGH",
            run_id=run_id,
            metadata={"high_pct": high_pct},
        )
        alerts.append(a)

    # Always log summary
    logger.info(f"Risk distribution check: CRITICAL={critical_pct:.1f}%, HIGH={high_pct:.1f}%")

    # Save alert summary CSV
    risky = df[df["risk_tier"].isin(["CRITICAL", "HIGH"])].copy()
    if not risky.empty:
        risky_path = os.path.join(ALERTS_DIR, "high_risk_cases.csv")
        risky.to_csv(risky_path, index=False)
        logger.info(f"High-risk cases saved: {risky_path} ({len(risky)} rows)")

    return alerts


def check_data_quality(quality_score: float, missing_pct: float, run_id: Optional[str] = None) -> List[dict]:
    """Raise alerts for data quality degradation."""
    alerts = []
    config = _load_config()
    thresholds = config.get("alert_thresholds", {})

    if quality_score < thresholds.get("quality_score_min", 70):
        a = raise_alert(
            title="Data Quality Below Threshold",
            message=f"Quality score {quality_score:.1f} is below minimum {thresholds.get('quality_score_min', 70)}.",
            severity="HIGH",
            run_id=run_id,
            metadata={"quality_score": quality_score},
        )
        alerts.append(a)

    if missing_pct > thresholds.get("max_missing_pct", 10):
        a = raise_alert(
            title="High Missing Data Rate",
            message=f"Missing data rate {missing_pct:.1f}% exceeds acceptable threshold {thresholds.get('max_missing_pct', 10)}%.",
            severity="MODERATE",
            run_id=run_id,
            metadata={"missing_pct": missing_pct},
        )
        alerts.append(a)

    return alerts


def check_model_performance(metrics: dict, run_id: Optional[str] = None) -> List[dict]:
    """Alert if model performance degrades below acceptable thresholds."""
    alerts = []
    for model_name, m in metrics.items():
        f1 = m.get("f1", 1.0)
        if f1 < 0.6:
            a = raise_alert(
                title=f"Model Performance Degradation: {model_name}",
                message=f"F1 score {f1:.4f} is below acceptable threshold 0.60.",
                severity="HIGH",
                run_id=run_id,
                metadata={"model": model_name, "f1": f1},
            )
            alerts.append(a)
    return alerts


def get_alert_history(n: int = 50) -> List[dict]:
    """Return the last N alerts from the alert log."""
    if not os.path.exists(ALERT_LOG):
        return []
    alerts = []
    with open(ALERT_LOG, "r") as f:
        for line in f:
            try:
                alerts.append(json.loads(line.strip()))
            except Exception:
                continue
    return alerts[-n:]
