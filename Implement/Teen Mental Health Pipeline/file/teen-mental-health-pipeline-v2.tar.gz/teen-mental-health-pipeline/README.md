# 🧠 Teen Mental Health Pipeline v2.0

> **Production-grade automated data engineering & ML system** for analyzing social media impact on teen mental health — with daily scheduling, retry logic, data versioning, quality reports, model comparison, and risk alerting.

---

## 📋 Project Overview

This pipeline ingests behavioral data (social media usage, sleep, stress, physical activity), cleans and validates it, engineers features, scores mental health risk, trains ML models, and serves insights through an interactive Streamlit dashboard.

**New in v2.0:**
- ⏰ **Scheduler** — APScheduler-based daily automated runs
- 🔁 **Retry Logic** — Exponential backoff on all I/O operations
- 📊 **Data Quality Report** — Standalone HTML report with visualizations
- 📈 **Model Comparison Viz** — Multi-panel comparison dashboard saved as PNG
- 🔔 **Alert System** — Risk threshold detection with email/webhook support
- 📁 **Data Versioning** — SHA256-checksummed snapshots with rollback support

---

## 🏗️ Architecture

```
Raw CSV
    │
    ▼
[Ingestion]  ←── retry, schema validation, versioning
    │
    ▼
[Validation] ←── missing values, ranges, outliers, quality score
    │
    ▼
[Quality Report] ←── HTML report with plots
    │
    ▼
[Cleaning]   ←── dedup, imputation, normalization, versioning
    │
    ▼
[Feature Eng] ←── ratios, risk index, encodings, versioning
    │
    ▼
[Risk Scoring] ←── rule-based 0–100 scoring + tier classification
    │
    ├──► [Alert System] ←── threshold checks, logs, notifications
    │
    ▼
[Database]   ←── SQLite WAL mode, run tracking
    │
    ▼
[ML Training] ←── LR + DT + RF, cross-validation, comparison charts
    │
    ▼
[Prediction] ←── model inference, high-risk flagging
    │
    ▼
[Dashboard]  ←── Streamlit: 8 pages, dark theme
```

---

## 📁 Project Structure

```
teen-mental-health-pipeline/
├── config/
│   ├── alert_config.json       # Email/webhook + threshold config
│   └── scheduler_config.json   # Daily run schedule settings
├── data/
│   ├── raw/                    # Original + timestamped raw copies
│   ├── processed/clean_data.csv
│   ├── features/feature_data.csv
│   ├── outputs/                # Risk scores, predictions, validation report
│   └── versions/               # SHA256-versioned snapshots + index
├── dashboard/app.py            # Streamlit dashboard (8 pages)
├── models/risk_model.pkl       # Best trained model bundle
├── logs/
│   ├── pipeline.log            # Rotating file log
│   ├── alerts.log              # Alert history (JSONL)
│   └── scheduler.log           # Scheduled run history
├── notebooks/eda.ipynb
├── reports/
│   ├── data_quality_report_*.html
│   ├── model_comparison_*.png
│   └── model_metrics.json
├── scripts/
│   ├── __init__.py
│   ├── logger.py               # Centralized rotating logger
│   ├── retry.py                # Retry decorator + safe_execute
│   ├── data_versioning.py      # Snapshot / rollback / diff
│   ├── data_ingestion.py
│   ├── data_validation.py
│   ├── data_cleaning.py
│   ├── feature_engineering.py
│   ├── risk_scoring.py
│   ├── database.py             # SQLite WAL storage
│   ├── train_model.py          # LR + DT + RF + comparison charts
│   ├── predict.py
│   ├── data_quality_report.py  # HTML report generator
│   ├── alert_system.py         # Risk + quality + model alerts
│   ├── scheduler.py            # APScheduler daily cron
│   └── run_pipeline.py         # Master orchestrator
├── requirements.txt
└── README.md
```

---

## ⚡ Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the full pipeline (manual)

```bash
cd teen-mental-health-pipeline
python scripts/run_pipeline.py
```

Options:
```bash
python scripts/run_pipeline.py --source data/raw/Teen_Mental_Health_Dataset.csv
python scripts/run_pipeline.py --run-id my_run_001 --skip-on-failure
```

### 3. Launch the dashboard

```bash
streamlit run dashboard/app.py
```

Open: http://localhost:8501

### 4. Start the daily scheduler

```bash
# Initialize default scheduler config
python scripts/scheduler.py --init-config

# Start scheduler (runs daily at 02:00 UTC)
python scripts/scheduler.py

# Start scheduler + trigger one immediate run
python scripts/scheduler.py --run-now
```

Edit `config/scheduler_config.json` to change the schedule hour/minute/timezone.

---

## 🆕 New Feature Details

### ⏰ Scheduler
- APScheduler cron trigger (daily at configurable time)
- Graceful SIGTERM/SIGINT shutdown
- Misfire grace window (1 hour)
- Persists run history to `logs/scheduler.log`

### 🔁 Retry Logic
- `@retry` decorator with exponential backoff
- Catches configurable exception types
- Applied to CSV loading and all DB writes
- `safe_execute()` for non-critical operations

### 📊 Data Quality Report
- HTML report with embedded base64 charts
- Scores: Completeness, Uniqueness, Validity, Overall
- Missing value bars, distribution histograms, correlation heatmap, outlier boxplots
- Saved to `reports/data_quality_report_<run_id>.html`

### 📈 Model Comparison Visualization
- Multi-panel dark-theme figure: bar chart, radar chart, 3× confusion matrices
- Saved to `reports/model_comparison_<run_id>.png`

### 🔔 Alert System
- Risk tier spike detection (configurable thresholds)
- Data quality degradation alerts
- Model performance degradation alerts
- Optional email (SMTP) and webhook (Slack/Teams) delivery
- Full alert history in `logs/alerts.log` (JSONL)
- Configure in `config/alert_config.json`

### 📁 Data Versioning
- SHA256 checksums for every snapshot
- Stages: raw → cleaned → features
- Version index at `data/versions/version_index.json`
- API: `snapshot()`, `load_latest()`, `rollback()`, `diff_versions()`

---

## 📊 Dashboard Pages

| Page | Description |
|------|-------------|
| 📊 Overview | KPIs, risk distribution, pipeline status |
| 🔍 Data Quality | Missing values, range violations, outliers |
| 📈 EDA & Correlations | Correlation heatmap, distribution explorer, scatter plots |
| ⚠️ Risk Analysis | Risk score distribution, platform breakdown, high-risk table |
| 🤖 Model Performance | Model comparison, confusion matrix, CV scores, feature importance |
| 🔮 Prediction | Interactive input form with risk gauge |
| 🔔 Alert Center | Alert history filtered by severity |
| 📁 Data Versioning | Snapshot browser, version diff tool |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Python 3.9+ |
| Data Processing | Pandas, NumPy |
| Machine Learning | Scikit-learn (LR, DT, RF) |
| Storage | SQLite (WAL mode) |
| Visualization | Matplotlib, Seaborn |
| Dashboard | Streamlit |
| Scheduling | APScheduler |
| Logging | Python logging + RotatingFileHandler |

---

## 🔧 Configuration

**Alert thresholds** (`config/alert_config.json`):
```json
{
  "alert_thresholds": {
    "critical_risk_pct": 20.0,
    "high_risk_pct": 40.0,
    "quality_score_min": 70.0,
    "max_missing_pct": 10.0
  }
}
```

**Scheduler** (`config/scheduler_config.json`):
```json
{
  "run_hour": 2,
  "run_minute": 0,
  "timezone": "UTC",
  "max_retries": 3
}
```
