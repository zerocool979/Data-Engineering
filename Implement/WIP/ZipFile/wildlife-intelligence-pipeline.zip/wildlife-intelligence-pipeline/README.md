# 🦁 WILDLIFE INTELLIGENCE PIPELINE

> Automated Data Engineering System for Wildlife Dataset Management

---

## 📦 Installation

```bash
pip install -r requirements.txt
```

## 🚀 Run

```bash
streamlit run dashboard/app.py
```

---

## 🏗️ Folder Structure

```
wildlife-intelligence-pipeline/
├── data/
│   ├── master/          ← Master dataset (animals_master.csv)
│   ├── uploads/         ← Uploaded CSV files (timestamped)
│   └── processed/       ← Clean, feature-engineered output (clean_data.csv)
├── scripts/
│   ├── upload_handler.py     ← Saves uploaded files
│   ├── data_cleaner.py       ← Cleans & normalizes data
│   ├── feature_engineering.py ← Adds Size/Speed Category
│   └── pipeline_runner.py    ← Orchestrates full pipeline
├── dashboard/
│   └── app.py           ← Streamlit UI
├── logs/
│   └── pipeline.log     ← Auto-generated pipeline logs
├── requirements.txt
└── README.md
```

---

## 🔄 Pipeline Flow

```
Upload CSV → Merge with Master → Remove Duplicates → Clean Data → Feature Engineering → Save → Dashboard
```

### Steps Explained

| Step | Description |
|------|-------------|
| **Upload** | User uploads CSV via Streamlit UI |
| **Merge** | New data concatenated with existing master dataset |
| **Dedup** | Removes duplicate animals by `Animal` column |
| **Clean** | Trims whitespace, handles nulls, converts numeric ranges |
| **Feature Eng.** | Adds `Size Category` (Small/Medium/Large) and `Speed Category` (Slow/Medium/Fast) |
| **Save** | Updates `data/processed/clean_data.csv` and `data/master/animals_master.csv` |
| **Dashboard** | Charts and search updated automatically |

---

## ✨ Features

- **📊 Dashboard** — Conservation status, habitat distribution, speed histogram, size categories, country distribution
- **🔍 Search Animal** — Full-text search with detailed animal profiles
- **📤 Upload Data** — Append-only CSV upload with auto pipeline execution
- **⬇ Download** — Export clean dataset as CSV
- **🔒 No Overwrite** — Master data is preserved; new data is appended and deduplicated

---

## 📐 Feature Engineering

### Size Category (based on Weight kg)
| Category | Weight |
|----------|--------|
| Small    | < 10 kg |
| Medium   | 10 – 100 kg |
| Large    | > 100 kg |

### Speed Category (based on Top Speed km/h)
| Category | Speed |
|----------|-------|
| Slow     | < 30 km/h |
| Medium   | 30 – 60 km/h |
| Fast     | > 60 km/h |
